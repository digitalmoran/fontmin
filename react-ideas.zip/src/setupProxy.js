/**
 * This file only supports commonjs JavaScript. First we extract
 * the GraphQL endpoint from the constants and then we configure
 * our webpack dev server proxy middleware.
 */
const proxy = require('http-proxy-middleware');
const fs = require('fs');
const cst = fs.readFileSync('./src/server/constants.ts').toString();
const gqlEndpoint = cst.match(/.*GRAPHQL_ENDPOINT .+'(.+)'/)[1];
const port = Number(process.env.PORT || 3000) + 1;

module.exports = (app) => {
  app.use(proxy(gqlEndpoint, { target: `http://localhost:${port}` }));
};
