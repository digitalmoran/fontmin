interface Window {
  __APOLLO_STATE__: any;
  __APOLLO_CLIENT__: any;
  Stickyfill: any;
  TinyAnimate: any;
  ResizeObserver: any;
}
