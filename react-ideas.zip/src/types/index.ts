import { ReduxState } from 'ra-core';

export interface AppState extends ReduxState {
  _prop?: any;
}
