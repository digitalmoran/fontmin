import { ApolloServer } from 'apollo-server-express';
// tslint:disable-next-line:no-submodule-imports
import { ExpressContext } from 'apollo-server-express/dist/ApolloServer';
import { GRAPHQL_ENDPOINT } from '../server/constants';
import { parseEnvironment } from '../lib/env';
import { createLoadersFromBatchFunctions, batchFunctions } from '../graphql/loaders';
import { resolvers } from '../graphql/resolvers';
import db from '../server/database';
import { GraphQLSchema } from 'graphql';

const isProd = process.env.NODE_ENV === 'production';

export const createServer = (schema: GraphQLSchema) =>
  new ApolloServer({
    schema,
    resolvers,
    context: (ctx: ExpressContext) => ({
      db,
      env: parseEnvironment(),
      req: ctx.req,
      loaders: createLoadersFromBatchFunctions(batchFunctions, {}),
    }),
    playground: !isProd ? { endpoint: GRAPHQL_ENDPOINT } : false,
    introspection: true,
  });
