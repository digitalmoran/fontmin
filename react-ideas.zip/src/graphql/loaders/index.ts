import * as DataLoader from 'dataloader';
import { getGeocodes, IGeocode } from '../models/Geocode';
import { getAddresses, IAddress } from '../models/Address';
import { getCounties, ICounty } from '../models/County';
import { getContacts, IContact } from '../models/Contact';
import { getLocations, ILocation } from '../models/Location';
import { getChapters, IChapter } from '../models/Chapter';
import { getProgramTypes, IProgramType } from '../models/ProgramType';
import { getRecognitionLevels, IRecognitionLevel } from '../models/RecognitionLevel';
import { getRoles, IRole } from '../models/Role';
import { getActivities, IActivity } from '../models/Activity';
import { getUsers, IUser } from '../models/User';
import { getPrograms, IProgram } from '../models/Program';
import { groupBy, map } from 'ramda';

/**
 * Creates curried batch dataloader functions that can receive
 * parameters:
 *
 * in Apollo Server context:
 * loaders: createLoadersFromBatchFunctions(batchFunctions, {});
 *
 * in resolver:
 * let result = await loaders.myCurriedBatchFn(parameter1).load(4);
 */
export const createLoadersFromBatchFunctions = (_batchFunctions: any, options: any) =>
  Object.entries(_batchFunctions).reduce((ack, [fnName, fnBody]: any) => {
    let fnRef: any; // This function ref will be updated on each call
    // @ts-ignore
    const dataloader = new DataLoader((ids: any) => fnRef(ids), options);
    return {
      ...ack,
      [fnName]: (...params: any) => {
        fnRef = fnBody(...params);
        return dataloader;
      },
    };
  }, {});

export const batchFunctions = {
  getGeocodes: (args: any, context: any) => async (ids: number[]) => {
    // batch query geocodes for the specified addressIds
    const geocodes = await getGeocodes({ addressIds: ids }, context);
    const groupedById = groupBy((geocode: IGeocode) => String(geocode.addressId), geocodes);
    return map((id: number) => groupedById[String(id)], ids);
  },
  getAddressesByIds: (args: any, context: any) => async (ids: number[]) => {
    // batch query addresses for the specified ids
    const addresses = await getAddresses({ ids }, context);
    const groupedById = groupBy((address: IAddress) => String(address.id), addresses);
    return map((id: number) => groupedById[String(id)], ids);
  },
  getAddressesByLocationIds: (args: any, context: any) => async (ids: number[]) => {
    // batch query addresses for the specified locationIds
    const addresses = await getAddresses({ locationIds: ids }, context);
    const groupedById = groupBy((address: IAddress) => String(address.locationId), addresses);
    return map((id: number) => groupedById[String(id)], ids);
  },
  getCountiesByLocationIds: (args: any, context: any) => async (ids: number[]) => {
    // batch query counties for the specified locationIds
    const counties = await getCounties({ locationIds: ids }, context);
    const groupedById = groupBy((county: ICounty) => String(county.locationId), counties);
    return map((id: number) => groupedById[String(id)], ids);
  },
  getCountiesByActivityLogIds: (args: any, context: any) => async (ids: number[]) => {
    // batch query counties for the specified activityLogIds
    const counties = await getCounties({ activityLogIds: ids }, context);
    const groupedById = groupBy((county: ICounty) => String(county.activityLogId), counties);
    return map((id: number) => groupedById[String(id)], ids);
  },
  getContactsByIds: (args: any, context: any) => async (ids: number[]) => {
    // batch query contacts for the specified ids
    const contacts = await getContacts({ ids }, context);
    const groupedById = groupBy((contact: IContact) => String(contact.id), contacts);
    return map((id: number) => groupedById[String(id)], ids);
  },
  getLocationsByIds: (args: any, context: any) => async (ids: number[]) => {
    // batch query locations for the specified ids
    const locations = await getLocations({ ids }, context);
    const groupedById = groupBy((location: ILocation) => String(location.id), locations);
    return map((id: number) => groupedById[String(id)], ids);
  },
  getProgramTypesByIds: (args: any, context: any) => async (ids: number[]) => {
    // batch query programTypes for the specified ids
    const programTypes = await getProgramTypes({ ids }, context);
    const groupedById = groupBy((type: IProgramType) => String(type.id), programTypes);
    return map((id: number) => groupedById[String(id)], ids);
  },
  getRecognitionLevelsByIds: (args: any, context: any) => async (ids: number[]) => {
    // batch query recognitionLevels for the specified ids
    const recognitionLevels = await getRecognitionLevels({ ids }, context);
    const groupedById = groupBy((level: IRecognitionLevel) => String(level.id), recognitionLevels);
    return map((id: number) => groupedById[String(id)], ids);
  },
  getChaptersByIds: (args: any, context: any) => async (ids: number[]) => {
    // batch query chapters for the specified ids
    const chapters = await getChapters({ ids }, context);
    const groupedById = groupBy((chapter: IChapter) => String(chapter.id), chapters);
    return map((id: number) => groupedById[String(id)], ids);
  },
  getPermissionsByUserIds: (args: any, context: any) => async (ids: number[]) => {
    // batch query roles for the specified userIds
    const roles = await getRoles({ userIds: ids }, context);
    const groupedById = groupBy((role: IRole) => String(role.userId), roles);
    return map((id: number) => groupedById[String(id)], ids);
  },
  getActivitiesByIds: (args: any, context: any) => async (ids: number[]) => {
    // batch query activities for the specified ids
    const activities = await getActivities({ ids }, context);
    const groupedById = groupBy((activity: IActivity) => String(activity.id), activities);
    return map((id: number) => groupedById[String(id)], ids);
  },
  getUsersByIds: (args: any, context: any) => async (ids: number[]) => {
    // batch query users for the specified ids
    const users = await getUsers({ ids }, context);
    const groupedById = groupBy((users: IUser) => String(users.id), users);
    return map((id: number) => groupedById[String(id)], ids);
  },
  getProgramsByIds: (args: any, context: any) => async (ids: number[]) => {
    // batch query programs for the specified ids
    const programs = await getPrograms({ ids }, context);
    const groupedById = groupBy((program: IProgram) => String(program.id), programs);
    return map((id: number) => groupedById[String(id)], ids);
  },
};
