import buildApolloClient, { buildQuery as buildQueryFactory } from 'ra-data-graphql-simple';
import { GET_ONE } from 'ra-core';
import gql from 'graphql-tag';
import { GRAPHQL_ENDPOINT, isProd, isLocalBuild } from '../server/constants';

const getGqlResource = (resource: string) => {
  switch (resource) {
    case 'users':
      return 'User';

    case 'chapters':
      return 'Chapter';

    case 'student-activity':
      return 'ActivityLog';

    case 'programs':
      return 'Program';

    case 'locations':
      return 'Location';

    case 'activity-type':
      return 'Activities';

    case 'program-type':
      return 'ProgramType';

    case 'recognition-level':
      return 'RecognitionLevel';

    default:
      throw new Error(`Unknown resource ${resource}`);
  }
};

const customBuildQuery = (introspectionResults: any) => {
  const buildQuery = buildQueryFactory(introspectionResults);

  return (type: string, resource: string, params: any) => {
    // console.log(type, resource, params);
    if (type === GET_ONE) {
      params.id = Number(params.id);
    }
    /*if (type === DELETE) {
      return {
        query: gql`mutation remove${resource}($id: ID!) {
                  remove${resource}(id: $id)
              }`,
        variables: { id: params.id },
        parseResponse: ({ data }: any) => {
          if (data[`remove${resource}`]) {
            return { data: { id: params.id } };
          }

          throw new Error(`Could not delete ${resource}`);
        },
      };
    }*/

    return buildQuery(type, resource, params);
  };
};

export default () => {
  return buildApolloClient({
    clientOptions: {
      uri: GRAPHQL_ENDPOINT,
    },
    introspection: {
      operationNames: {
        /*[DELETE]: (resource: any) => `remove${resource.name}`,*/
      },
    },
    buildQuery: customBuildQuery,
  }).then((dataProvider: any) => (type: string, resource: string, params: any) =>
    dataProvider(type, getGqlResource(resource), params)
  );
};
