import { IResolvers } from 'graphql-tools';
// @ts-ignore - this package has no type definitions
import { DateTime, Date, Coordinates /*Url, PhoneNumber, Email*/ } from '@veriown/graphql-scalars';
// https://github.com/Urigo/graphql-scalars
import { JSONObjectResolver, RegularExpression, NonNegativeFloatResolver } from 'graphql-scalars';
import { getActivities } from '../models/Activity';
import { getCounties } from '../models/County';
import { getProgramTypes } from '../models/ProgramType';
import { getRecognitionLevels } from '../models/RecognitionLevel';
import { getRoles } from '../models/Role';
import { getGeocodes } from '../models/Geocode';
import { getAddresses } from '../models/Address';
import { getContacts } from '../models/Contact';
import { getLocations } from '../models/Location';
import { getChapters } from '../models/Chapter';
import { getPrograms } from '../models/Program';
import { getUsers } from '../models/User';
import { getActivityLogs } from '../models/ActivityLog';

/**
 * GraphQL Resolvers
 *
 * (parent, args, context, info) => resolverFunction(...neededArguments)
 * Resolvers that query the database connection need to use async/await.
 * https://www.apollographql.com/docs/apollo-server/essentials/data.html#type-signature
 */

const PostalCodeOrNA = new RegularExpression('PostalCodeOrNA', /^(\d{5}([-]?\d{4})?||n\/a)$/);
const PhoneNumberOrNA = new RegularExpression(
  'PhoneNumberOrNA',
  /(1?\W*([2-9][0-8][0-9])\W*([2-9][0-9]{2})\W*([0-9]{4})(,?\s?[Ee]?x?t?(\.|ension)?\s?(\d*))?|n\/a)/
);
const EmailOrNA = new RegularExpression(
  'EmailOrNA',
  /^((?:[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?\.)+[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[A-Za-z0-9-]*[A-Za-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])|n\/a)$/
);

const BcryptHash = new RegularExpression('BcryptHash', /\$2[ayb]\$.{56}$/);

export const resolvers: IResolvers = {
  BcryptHash,
  DateTime,
  Date,
  Coordinates,
  PhoneNumberOrNA,
  EmailOrNA,
  JSONObject: JSONObjectResolver,
  PostalCodeOrNA,
  NonNegativeFloat: NonNegativeFloatResolver,
  Query: {
    /*activities: async (_, args, context) => getActivities(args, context),
    counties: async (_, args, context) => getCounties(args, context),
    programTypes: async (_, args, context) => getProgramTypes(args, context),
    recognitionLevels: async (_, args, context) => getRecognitionLevels(args, context),
    roles: async (_, args, context) => getRoles(args, context),
    geocodes: async (_, args, context) => getGeocodes(args, context),
    addresses: async (_, args, context) => getAddresses(args, context),
    contacts: async (_, args, context) => getContacts(args, context),
    locations: async (_, args, context) => getLocations(args, context),
    chapters: async (_, args, context) => getChapters(args, context),
    programs: async (_, args, context) => getPrograms(args, context),
    users: async (_, args, context) => getUsers(args, context),
    activityLogs: async (_, args, context) => getActivityLogs(args, context),*/
    User: async (_, args, context) => (await getUsers(args, context))[0],
    allUsers: async (_, args, context) => getUsers(args, context),
    _allUsersMeta: async (_, args, context) => ({
      count: (await getUsers({ ...args, page: undefined }, context)).length,
    }),
  },
  Address: {
    geocodes: async (address, args, context) => {
      const { loaders } = context;
      const result = await loaders.getGeocodes(args, context).load(address.id);
      return result;
    },
  },
  Contact: {
    address: async (contact, args, context) => {
      if (contact.addressId !== null) {
        const { loaders } = context;
        const results = await loaders.getAddressesByIds(args, context).load(contact.addressId);
        return results[0] || null;
      }
      return null;
    },
  },
  Location: {
    supervisor: async (location, args, context) => {
      if (location.supervisorContactId) {
        const { loaders } = context;
        const results = await loaders
          .getContactsByIds(args, context)
          .load(location.supervisorContactId);
        return results[0] || null;
      }
      return null;
    },
    addresses: async (location, args, context) => {
      const { loaders } = context;
      const results = await loaders.getAddressesByLocationIds(args, context).load(location.id);
      return results;
    },
    counties: async (location, args, context) => {
      const { loaders } = context;
      const results = await loaders.getCountiesByLocationIds(args, context).load(location.id);
      return results;
    },
  },
  Chapter: {
    location: async (chapter, args, context) => {
      const { loaders } = context;
      const results = await loaders.getLocationsByIds(args, context).load(chapter.locationId);
      return results[0] || null;
    },
    coordinator: async (chapter, args, context) => {
      const { loaders } = context;
      const results = await loaders.getContactsByIds(args, context).load(chapter.contactId);
      return results[0] || null;
    },
  },
  Program: {
    programType: async (program, args, context) => {
      const { loaders } = context;
      const results = await loaders.getProgramTypesByIds(args, context).load(program.programTypeId);
      return results[0] || null;
    },
    supervisor: async (program, args, context) => {
      if (program.supervisorContactId) {
        const { loaders } = context;
        const results = await loaders
          .getContactsByIds(args, context)
          .load(program.supervisorContactId);
        return results[0] || null;
      }
      return null;
    },
  },
  User: {
    contact: async (user, args, context) => {
      if (user.contactId) {
        const { loaders } = context;
        const results = await loaders.getContactsByIds(args, context).load(user.contactId);
        return results[0] || null;
      }
      return null;
    },
    emergencyContact: async (user, args, context) => {
      if (user.emergencyContactId) {
        const { loaders } = context;
        const results = await loaders.getContactsByIds(args, context).load(user.emergencyContactId);
        return results[0] || null;
      }
      return null;
    },
    recognitionLevel: async (user, args, context) => {
      if (user.recognitionId) {
        const { loaders } = context;
        const results = await loaders
          .getRecognitionLevelsByIds(args, context)
          .load(user.recognitionId);
        return results[0] || null;
      }
      return null;
    },
    chapter: async (user, args, context) => {
      const { loaders } = context;
      const results = await loaders.getChaptersByIds(args, context).load(user.chapterId);
      return results[0] || null;
    },
    permissions: async (user, args, context) => {
      const { loaders } = context;
      const results = await loaders.getPermissionsByUserIds(args, context).load(user.id);
      return results;
    },
  },
  ActivityLog: {
    activityType: async (activityLog, args, context) => {
      const { loaders } = context;
      const results = await loaders.getActivitiesByIds(args, context).load(activityLog.activityId);
      return results[0] || null;
    },
    user: async (activityLog, args, context) => {
      const { loaders } = context;
      const results = await loaders.getUsersByIds(args, context).load(activityLog.userId);
      return results[0] || null;
    },
    chapter: async (activityLog, args, context) => {
      const { loaders } = context;
      const results = await loaders.getChaptersByIds(args, context).load(activityLog.chapterId);
      return results[0] || null;
    },
    program: async (activityLog, args, context) => {
      const { loaders } = context;
      const results = await loaders.getProgramsByIds(args, context).load(activityLog.programId);
      return results[0] || null;
    },
    location: async (activityLog, args, context) => {
      const { loaders } = context;
      const results = await loaders.getLocationsByIds(args, context).load(activityLog.locationId);
      return results[0] || null;
    },
    instructor: async (activityLog, args, context) => {
      const { loaders } = context;
      const results = await loaders
        .getContactsByIds(args, context)
        .load(activityLog.instructorContactId);
      return results[0] || null;
    },
    counties: async (activityLog, args, context) => {
      const { loaders } = context;
      const results = await loaders.getCountiesByActivityLogIds(args, context).load(activityLog.id);
      return results;
    },
  },
  Mutation: {
    createUser: async () => ({}),
    updateUser: async () => ({}),
    deleteUser: async () => ({}),
  },
};
