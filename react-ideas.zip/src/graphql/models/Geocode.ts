import { getConnection, IContextParams } from './index';

export interface IGeocode {
  id: number;
  addressId: number;
  point: { lat: number; lng: number };
  pointType: 'CENTER' | 'BBOX_UPPER_LEFT' | 'BBOX_LOWER_RIGHT' | 'MARKER';
  imageData?: string;
  json?: any;
}

interface IGeocodeParams {
  addressIds?: number[];
}

const pointTypeKeys: string[] = ['center', 'bbox1', 'bbox2', 'marker'];
const pointTypeValues: Array<IGeocode['pointType']> = [
  'CENTER',
  'BBOX_UPPER_LEFT',
  'BBOX_LOWER_RIGHT',
  'MARKER',
];

/**
 * Returns a list of Geocode objects selected by a list of
 * address_ID's. If no select list is provided, a list of
 * all Geocode objects in the database is returned.
 *
 * @param {Object<IGeocodeParams>} args
 * @param {Array<number>} args.addressIds
 * @param {Object<IContextParams>} context
 * @param {Promise<Pool>} context.db
 * @param {Promise<ProcessEnv>} context.env
 *
 * @returns {Promise<IGeocode[]>}
 */
export const getGeocodes = async (
  { addressIds = [] }: IGeocodeParams,
  { db, env }: IContextParams
) => {
  const db1 = await env.DB1;
  const con = await getConnection(db);
  const hasAddress = addressIds && addressIds.length;
  const where = hasAddress ? `WHERE ag.address_ID IN (${addressIds.join(', ')})` : '';
  const sql = `
    SELECT g.ID AS id
           ,g.latitude
           ,g.longitude
           ,g.point_type AS pointType
           ,g.json
           ,g.image_data AS imageData
           ,ag.address_ID AS addressId
      FROM ${db1}.geocodes AS g
           INNER JOIN ${db1}.address_geocodes AS ag
            ON g.ID = ag.geocode_ID
     ${where}
     ORDER BY g.ID
  `;
  try {
    const results = await con.query(sql, []);
    con.release();

    const geocodes: IGeocode[] = [];
    results.forEach((r: any) => {
      const code: IGeocode = {
        id: r.id,
        addressId: r.addressId,
        point: { lat: r.latitude, lng: r.longitude },
        pointType: pointTypeValues[pointTypeKeys.indexOf(r.pointType)],
        imageData: r.imageData || null,
        json: (r.json && JSON.parse(r.json)) || null,
      };
      geocodes.push(code);
    });

    return geocodes;
  } catch (error) {
    console.error(error);
    con.release();
    return [];
  }
};
