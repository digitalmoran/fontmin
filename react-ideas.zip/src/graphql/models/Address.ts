import { getConnection, IContextParams } from './index';
import { IGeocode } from './Geocode';

export interface IAddress {
  id: number;
  locationId?: number;
  address1?: string;
  address2?: string;
  city: string;
  state: string;
  zipCode: string;
  addressType: 'MAILING' | 'PHYSICAL';
  memo?: string;
  geocodes?: Array<IGeocode>;
  createDate: string;
  updateDate?: string;
  updatedByUserId?: number;
}

interface IAddressParams {
  ids?: number[];
  locationIds?: number[];
}

const addressTypeKeys: string[] = ['mailing', 'physical'];
const addressTypeValues: Array<IAddress['addressType']> = ['MAILING', 'PHYSICAL'];

/**
 * Returns a list of Address objects selected by either a list of
 * address_ID's or location_ID's. If neither select list is provided,
 * a list of all Address objects in the database is returned.
 *
 * @param {Object<IAddressParams>} args
 * @param {Array<number>} args.ids
 * @param {Array<number>} args.locationIds
 * @param {Object<IContextParams>} context
 * @param {Promise<Pool>} context.db
 * @param {Promise<ProcessEnv>} context.env
 *
 * @returns {Promise<IAddress[]>}
 */
export const getAddresses = async (
  { ids = [], locationIds = [] }: IAddressParams,
  { db, env }: IContextParams
): Promise<IAddress[]> => {
  let where = 'WHERE a.ID > 0';
  const db1 = await env.DB1;
  const con = await getConnection(db);
  const hasAddress = ids && ids.length;
  const hasLocation = locationIds && locationIds.length;
  const join = hasLocation
    ? `INNER JOIN ${db1}.location_addresses AS la
      ON a.id = la.address_ID`
    : '';

  where = hasLocation ? `WHERE la.location_ID IN (${locationIds.join(', ')})` : where;
  where = hasAddress ? `WHERE a.ID IN (${ids.join(', ')})` : where;
  const select = hasLocation ? ',la.location_ID AS locationId' : '';

  const sql = `
    SELECT a.ID AS id
           ${select}
           ,a.address_1 AS address1
           ,a.address_2 AS address2
           ,a.city
           ,a.state
           ,a.zip_code AS zipCode
           ,a.address_type AS addressType
           ,a.memo
           ,a.create_date AS createDate
           ,a.update_date AS updateDate
           ,a.updated_by_user_ID AS updatedByUserId
      FROM ${db1}.addresses AS a
           ${join}
     ${where}
     ORDER BY a.ID
  `;
  try {
    const results = await con.query(sql, []);
    con.release();

    const addresses: IAddress[] = [];
    results.forEach((r: any) => {
      const address: IAddress = {
        id: r.id,
        locationId: r.locationId || null,
        address1: r.address1,
        address2: r.address2,
        city: r.city,
        state: r.state,
        zipCode: r.zipCode,
        addressType: addressTypeValues[addressTypeKeys.indexOf(r.addressType)],
        memo: r.memo,
        createDate: r.createDate,
        updateDate: r.updateDate,
        updatedByUserId: r.updatedByUserId,
      };
      addresses.push(address);
    });

    return addresses;
  } catch (error) {
    console.error(error);
    con.release();
    return [];
  }
};
