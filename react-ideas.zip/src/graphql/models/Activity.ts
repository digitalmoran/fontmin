import { getConnection, IContextParams } from './index';

export interface IActivity {
  id: number;
  description: string;
  createDate: string;
  updateDate?: string;
  updatedByUserId?: number;
}

interface IActivityParams {
  ids?: number[];
}

/**
 * Returns a list of Activity objects selected by a list of
 * activity_ID's. If no select list is provided, a list of
 * all Activity objects in the database is returned.
 *
 * @param {Object<IActivityParams>} args
 * @param {Array<number>} args.ids
 * @param {Object<IContextParams>} context
 * @param {Promise<Pool>} context.db
 * @param {Promise<ProcessEnv>} context.env
 *
 * @returns {Promise<IActivity[]>}
 */
export const getActivities = async ({ ids = [] }: IActivityParams, { db, env }: IContextParams) => {
  const db1 = await env.DB1;
  const con = await getConnection(db);
  const hasActivity = ids && ids.length;
  const where = hasActivity ? `WHERE ID IN (${ids.join(', ')})` : '';
  const sql = `
    SELECT ID as id
           ,activity_description AS description
           ,create_date AS createDate
           ,update_date AS updateDate
           ,updated_by_user_ID AS updatedByUserId
      FROM ${db1}.activities ${where}
     ORDER BY ID
  `;
  const results = await con.query(sql, []);
  con.release();

  return results;
};
