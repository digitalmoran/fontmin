import { getConnection, IContextParams } from './index';
import { ILocation } from './Location';
import { IContact } from './Contact';

export interface IChapter {
  id: number;
  locationId: number;
  contactId: number;
  name: string;
  originDate?: string;
  agreement?: string;
  location?: ILocation;
  coordinator?: IContact;
  memo?: string;
  createDate: string;
  updateDate?: string;
  updatedByUserId?: number;
  active: boolean;
}

interface IChapterParams {
  ids: number[];
  active?: boolean | null;
}

/**
 * Returns a list of Chapter objects selected by a list of
 * chapter_ID's. If no select list is provided, a list of
 * all Chapter objects in the database is returned.
 *
 * @param {Object<IChapterParams>} args
 * @param {Array<number>} args.ids
 * @param {boolean} args.active
 * @param {Object<IContextParams>} context
 * @param {Promise<Pool>} context.db
 * @param {Promise<ProcessEnv>} context.env
 *
 * @returns {Promise<IChapter[]>}
 */
export const getChapters = async (
  { ids = [], active }: IChapterParams,
  { db, env }: IContextParams
) => {
  const db1 = await env.DB1;
  const con = await getConnection(db);
  const hasChapter = ids && ids.length;
  const hasActive = active !== undefined && active !== null;
  let where = hasChapter ? `WHERE c.ID IN (${ids.join(', ')})` : '';
  if (hasActive) {
    where = hasChapter ? `${where} AND c.active = ${active}` : `WHERE c.active = ${active}`;
  }
  const sql = `
    SELECT c.ID AS id
           ,c.location_ID AS locationId
           ,c.contact_ID AS contactId
           ,c.chapter_name AS name
           ,c.chapter_origin_date AS originDate
           ,c.chapter_agreement AS agreement
           ,c.memo
           ,c.create_date AS createDate
           ,c.update_date AS updateDate
           ,c.updated_by_user_ID AS updatedByUserId
           ,c.active
      FROM ${db1}.chapters AS c
     ${where}
     ORDER BY c.ID
  `;
  try {
    const results: IChapter[] = await con.query(sql, []);
    con.release();
    return results;
  } catch (error) {
    console.error(error);
    con.release();
    return [];
  }
};
