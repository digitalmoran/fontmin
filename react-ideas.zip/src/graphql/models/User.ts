import {
  getConnection,
  IContextParams,
  joinTables,
  sortFieldToOrderByField,
  getFilterJoins,
  getWhereCondition,
  getWhereColumn,
} from './index';
import { IContact } from './Contact';
import { IRecognitionLevel } from './RecognitionLevel';
import { IChapter } from './Chapter';
import { IRole } from './Role';

export interface IUser {
  id: number;
  contactId: number;
  emergencyContactId?: number;
  recognitionId?: number;
  chapterId: number;
  username: string;
  password: string;
  contact: IContact;
  emergencyContact?: IContact;
  recognitionLevel?: IRecognitionLevel;
  chapter: IChapter;
  permissions: IRole[];
  firstClassYear?: number;
  initialTestScore?: number;
  finalTestScore?: number;
  liabilityForm?: string;
  memo?: string;
  createDate: string;
  updateDate?: string;
  updatedByUserId?: number;
  active: boolean;
}

interface IUserParams {
  id?: number;
  ids?: number[];
  chapterIds?: number[];
  usernames?: string[];
  active?: boolean | null;
  page?: number;
  perPage?: number;
  sortField?: string;
  sortOrder?: string;
  filter?: any;
}

/**
 * Returns a list of User objects selected by a list of
 * user_ID's, chapter_ID's, or username's. If no select
 * list is provided, a list of all Chapter objects in
 * the database is returned.
 *
 * @param {Object<IUserParams>} args
 * @param {Array<number>} args.ids
 * @param {Array<number>} args.chapterIds
 * @param {username} args.username
 * @param {boolean} args.active
 * @param {Object<IContextParams>} context
 * @param {Promise<Pool>} context.db
 * @param {Promise<ProcessEnv>} context.env
 *
 * @returns {Promise<IUser[]>}
 */
export const getUsers = async (
  {
    page,
    perPage,
    sortField = 'id',
    sortOrder = 'ASC',
    filter = {},
    id,
    ids = [],
    chapterIds = [],
    usernames = [],
    active,
  }: IUserParams,
  { db, env }: IContextParams
) => {
  const db1 = await env.DB1;
  const con = await getConnection(db);
  const hasUser = (ids && ids.length) || id !== undefined;
  const hasChapter = chapterIds && chapterIds.length;
  const hasUsername = usernames && usernames.length;
  const hasActive = active !== undefined && active !== null;
  let _sortField = 'id' ? 'u.ID' : sortField;
  let hasFilter: boolean = Object.keys(filter).length > 0;

  let limit = '';
  let join = '';
  let where = hasUser ? `WHERE u.ID IN (${ids.join(', ') || id})` : 'WHERE u.ID > 0';
  where = hasChapter ? `WHERE u.chapter_ID IN (${chapterIds.join(', ')})` : where;
  where = hasUsername ? `WHERE u.username IN (${usernames.join(', ')})` : where;

  if (hasActive) {
    where = where !== '' ? `${where} AND u.active = ${active}` : `WHERE u.active = ${active}`;
  }

  if (page !== undefined && perPage !== undefined) {
    const offset = page * perPage;
    limit = `LIMIT ${offset},${perPage}`;
  }

  // Search filter
  if (filter.q) {
    let conditions;
    const phone = filter.q.replace(/\D/g, '');
    conditions = `c.full_name LIKE '%${filter.q}%'`;
    conditions += ` OR ch.chapter_name LIKE '%${filter.q}%'`;
    conditions += ` OR u.username LIKE '%${filter.q}%'`;
    conditions += ` OR c.email LIKE '%${filter.q}%'`;
    conditions += ` OR a.address_1 LIKE '%${filter.q}%'`;
    conditions += ` OR a.address_2 LIKE '%${filter.q}%'`;
    conditions += ` OR a.city LIKE '%${filter.q}%'`;
    conditions += ` OR a.state LIKE '%${filter.q}%'`;
    conditions += ` OR a.zip_code LIKE '%${filter.q}%'`;
    conditions += ` OR c.phone LIKE '%${phone || filter.q}%'`;
    conditions += ` OR c.title LIKE '%${filter.q}%'`;
    conditions += ` OR u.memo LIKE '%${filter.q}%'`;
    conditions += ` OR rl.level_name LIKE '%${filter.q}%'`;
    where += ` AND (${conditions})`;
  }

  // All other filters
  if (Object.keys(filter).length) {
    let conditions = '';
    for (const k in filter) {
      if (k === 'q' || k.indexOf('Where') > -1) continue;
      const v: any = typeof filter[k] === 'boolean' ? Number(filter[k]) : filter[k];
      conditions += ` AND (${getWhereCondition(filter[`${k}Where`], v, getWhereColumn('u', k))})`;
    }
    join = getFilterJoins(db1, 'users');
    _sortField = sortFieldToOrderByField(sortField);
    where += conditions;
  }

  if (sortField !== 'id' && !hasFilter) {
    switch (sortField) {
      case 'contact.fullName':
      case 'contact.email':
      case 'contact.phone':
      case 'contact.title':
        join = joinTables(db1, 'users', 'contacts', 'contact_ID', 'ID');
        break;
      case 'chapter.name':
        join = joinTables(db1, 'users', 'chapters', 'chapter_ID', 'ID');
        break;
      case 'permissions':
        join = joinTables(db1, 'users', 'permissions', 'ID', 'user_ID');
        break;
      case 'contact.address.address1':
      case 'contact.address.address2':
      case 'contact.address.city':
      case 'contact.address.state':
      case 'contact.address.zipCode':
        join = joinTables(db1, 'users', 'contacts', 'contact_ID', 'ID');
        join += joinTables(db1, 'contacts', 'addresses', 'address_ID', 'ID');
        break;
    }
    _sortField = sortFieldToOrderByField(sortField);
  }

  const sql = `
    SELECT u.ID AS id
           ,u.contact_ID AS contactId
           ,u.emergency_contact_ID AS emergencyContactId
           ,u.recognition_ID AS recognitionId
           ,u.chapter_ID AS chapterId
           ,u.username
           ,u.password
           ,u.first_class_year AS firstClassYear
           ,u.initial_test_score AS initialTestScore
           ,u.final_test_score AS finalTestScore
           ,u.liability_form AS liabilityForm
           ,u.memo
           ,u.create_date AS createDate
           ,u.update_date AS updateDate
           ,u.updated_by_user_ID AS updatedByUserId
           ,u.active
      FROM ${db1}.users AS u ${join}
     ${where}
     ${hasFilter ? 'GROUP BY u.ID ORDER' : 'ORDER'} BY ${_sortField} ${sortOrder} ${limit}
  `;
  try {
    console.log(sql);
    const results: IUser[] = await con.query(sql, []);
    con.release();
    return results;
  } catch (error) {
    console.error(error);
    con.release();
    return [];
  }
};
