import { getConnection, IContextParams } from './index';
import { IProgramType } from './ProgramType';
import { IContact } from './Contact';

export interface IProgram {
  id: number;
  programTypeId: number;
  supervisorContactId?: number;
  name: string;
  mandatory: boolean;
  programType: IProgramType;
  supervisor?: IContact;
  memo?: string;
  createDate: string;
  updateDate?: string;
  updatedByUserId?: number;
  approved: number;
  active: boolean;
}

interface IProgramParams {
  ids?: number[];
  programTypeIds?: number[];
  contactIds?: number[];
  approved?: number | null;
  active?: boolean | null;
}

/**
 * Returns a list of Program objects selected by a list of
 * program_ID's, program_type_ID's, or contact_ID's. If no select
 * list is provided, a list of all Program objects in the database
 * is returned.
 *
 * @param {Object<IAddressParams>} args
 * @param {Array<number>} args.ids
 * @param {Array<number>} args.programTypeIds
 * @param {Array<number>} args.contactIds
 * @param {number} args.approved
 * @param {boolean} args.active
 * @param {Object<IContextParams>} context
 * @param {Promise<Pool>} context.db
 * @param {Promise<ProcessEnv>} context.env
 *
 * @returns {Promise<IProgram[]>}
 */
export const getPrograms = async (
  {
    ids = [],
    programTypeIds = [],
    contactIds = [],
    approved = null,
    active = null,
  }: IProgramParams,
  { db, env }: IContextParams
): Promise<IProgram[]> => {
  let where = 'WHERE p.ID > 0';
  const db1 = await env.DB1;
  const con = await getConnection(db);
  const hasProgram = ids && ids.length;
  const hasProgamType = programTypeIds && programTypeIds.length;
  const hasContact = contactIds && contactIds.length;

  where = hasProgram ? `WHERE p.ID IN (${ids.join(', ')})` : where;
  where = hasProgamType ? `WHERE p.program_type_ID IN (${programTypeIds.join(', ')})` : where;
  where = hasContact ? `WHERE p.supervisor_contact_ID IN (${contactIds.join(', ')})` : where;
  where = approved !== null ? `${where} AND p.approved = ${approved}` : where;
  where = active !== undefined && active !== null ? `${where} AND p.active = ${active}` : where;

  const sql = `
    SELECT p.ID AS id
           ,p.program_type_ID AS programTypeId
           ,p.supervisor_contact_ID AS supervisorContactId
           ,p.program_name AS name
           ,p.mandatory
           ,p.memo
           ,p.create_date AS createDate
           ,p.update_date AS updateDate
           ,p.updated_by_user_ID AS updatedByUserId
           ,p.approved
           ,p.active
      FROM ${db1}.programs AS p
     ${where}
     ORDER BY p.ID
  `;
  try {
    const results = await con.query(sql, []);
    con.release();

    return results;
  } catch (error) {
    console.error(error);
    con.release();
    return [];
  }
};
