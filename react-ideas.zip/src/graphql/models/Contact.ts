import { getConnection, IContextParams } from './index';
import { IAddress } from './Address';

export interface IContact {
  id: number;
  addressId?: number;
  title?: string;
  fullName: string;
  gender?: string;
  phone: string;
  email?: string;
  address?: IAddress;
  memo?: string;
  createDate: string;
  updateDate?: string;
  updatedByUserId?: number;
}

interface IContactParams {
  ids: number[];
}

/**
 * Returns a list of Contact objects selected by a list of
 * contact_ID's. If no select list is provided, a list of
 * all Contact objects in the database is returned.
 *
 * @param {Object<IContactParams>} args
 * @param {Array<number>} args.ids
 * @param {Object<IContextParams>} context
 * @param {Promise<Pool>} context.db
 * @param {Promise<ProcessEnv>} context.env
 *
 * @returns {Promise<IContact[]>}
 */
export const getContacts = async ({ ids = [] }: IContactParams, { db, env }: IContextParams) => {
  const db1 = await env.DB1;
  const con = await getConnection(db);
  const hasContact = ids && ids.length;
  const where = hasContact ? `WHERE c.ID IN (${ids.join(', ')})` : '';
  const sql = `
    SELECT c.ID AS id
           ,c.address_ID AS addressId
           ,c.title
           ,c.full_name AS fullName
           ,c.gender
           ,c.phone
           ,c.email
           ,c.memo
           ,c.create_date AS createDate
           ,c.update_date AS updateDate
           ,c.updated_by_user_ID AS updatedByUserId
      FROM ${db1}.contacts AS c
     ${where}
     ORDER BY c.ID
  `;
  try {
    const results: IContact[] = await con.query(sql, []);
    con.release();
    return results;
  } catch (error) {
    console.error(error);
    con.release();
    return [];
  }
};
