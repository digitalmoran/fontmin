import { Pool } from 'mysql';
import * as fs from 'fs';

export const getConnection = async function(db: any) {
  try {
    await db;
    const pool = db.value();
    const con = await pool.getConnection();
    return con;
  } catch (err) {
    console.error(err);
    fs.writeFileSync(`${process.cwd()}/error.log`, JSON.stringify(err, null, 2), {
      encoding: 'utf8',
      flag: 'a',
    });
  }
};

export interface IContextParams {
  db: Promise<Pool>;
  env: { [key: string]: any };
}

export const tableNameToAbbreviation = (name: string): string => {
  switch (name) {
    case 'activities':
      return 'at';
    case 'activity_counties':
      return 'ac';
    case 'activity_logs':
      return 'al';
    case 'address_geocodes':
      return 'ag';
    case 'addresses':
      return 'a';
    case 'chapters':
      return 'ch';
    case 'contacts':
      return 'c';
    case 'counties':
      return 'ct';
    case 'geocodes':
      return 'g';
    case 'location_addresses':
      return 'la';
    case 'location_counties':
      return 'lc';
    case 'locations':
      return 'l';
    case 'permissions':
      return 'pm';
    case 'program_types':
      return 'pt';
    case 'programs':
      return 'p';
    case 'recognition_levels':
      return 'rl';
    case 'roles':
      return 'r';
    case 'users':
      return 'u';
  }
  return '';
};

export const AbbreviationToTableName = (name: string): string => {
  switch (name) {
    case 'at':
      return 'activities';
    case 'ac':
      return 'activity_counties';
    case 'al':
      return 'activity_logs';
    case 'ag':
      return 'address_geocodes';
    case 'a':
      return 'addresses';
    case 'ch':
      return 'chapters';
    case 'c':
      return 'contacts';
    case 'ct':
      return 'counties';
    case 'g':
      return 'geocodes';
    case 'la':
      return 'location_addresses';
    case 'lc':
      return 'location_counties';
    case 'l':
      return 'locations';
    case 'pm':
      return 'permissions';
    case 'pt':
      return 'program_types';
    case 'p':
      return 'programs';
    case 'rl':
      return 'recognition_levels';
    case 'r':
      return 'roles';
    case 'u':
      return 'users';
  }
  return '';
};

export const sortFieldToOrderByField = (field: string): string => {
  let orderField: string = '';
  const tn = tableNameToAbbreviation;
  switch (field) {
    case 'contact.fullName':
      orderField = `${tn('contacts')}.full_name`;
      break;
    case 'chapter.name':
      orderField = `${tn('chapters')}.chapter_name`;
      break;
    case 'contact.email':
      orderField = `${tn('contacts')}.email`;
      break;
    case 'contact.address.address1':
      orderField = `${tn('addresses')}.address_1`;
      break;
    case 'contact.address.address2':
      orderField = `${tn('addresses')}.address_2`;
      break;
    case 'contact.address.city':
      orderField = `${tn('addresses')}.city`;
      break;
    case 'contact.address.state':
      orderField = `${tn('addresses')}.state`;
      break;
    case 'contact.address.zipCode':
      orderField = `${tn('addresses')}.zip_code`;
      break;
    case 'contact.phone':
      orderField = `${tn('contacts')}.phone`;
      break;
    case 'contact.title':
      orderField = `${tn('contacts')}.title`;
      break;
    case 'recognitionLevel.name':
      orderField = `${tn('users')}.recognition_ID`;
      break;
    case 'permissions':
      orderField = `${tn('permissions')}.role_ID`;
      break;
    default:
      orderField = field;
  }
  return orderField;
};

const pad = (pattern: string, count: number): string => {
  return Array(count + 1).join(pattern);
};

export const joinTables = (
  dbName: string,
  table1: string,
  table2: string,
  key1: string,
  key2: string,
  joinType: string = 'INNER'
): string => {
  const t1 = tableNameToAbbreviation(table1);
  const t2 = tableNameToAbbreviation(table2);
  let join: string =
    `\n${pad(' ', 11)}${joinType} JOIN ${dbName}.${table2} AS ${t2}\n` +
    `${pad(' ', 11)}  ON ${t1}.${key1} = ${t2}.${key2} `;
  return join;
};

export const getFilterJoins = (db: string, table: string): string => {
  let join: string = '';
  switch (table) {
    case 'users':
      join += joinTables(db, table, 'contacts', 'contact_ID', 'ID');
      join += joinTables(db, 'contacts', 'addresses', 'address_ID', 'ID', 'LEFT');
      join += joinTables(db, table, 'chapters', 'chapter_ID', 'ID');
      join += joinTables(db, table, 'permissions', 'ID', 'user_ID');
      join += joinTables(db, 'permissions', 'roles', 'role_ID', 'ID');
      join += joinTables(db, table, 'recognition_levels', 'recognition_ID', 'ID', 'LEFT');
      break;
  }
  return join;
};

export const cleanPhoneNumber = (phone: string) => {
  const rgx = /1?\W*([2-9][0-8][0-9])\W*([2-9][0-9]{2})\W*([0-9]{4})(,?\s?[Ee]?x?t?(\.|ension)?\s?(\d*))?/;
  let output = '';
  const match = phone.match(rgx);
  if (match && match[0]) {
    output += `${match[1]}${match[2]}${match[3]}`;
    if (match[6]) {
      output += ` ${match[6]}`;
    }
    return output;
  }
  return phone;
};

export const getWhereCondition = (whereField: string, value: any, key: string) => {
  const quote = typeof value === 'number' ? '' : "'";
  const isPhone = key === 'c.phone' ? true : false;
  let values = whereField.indexOf('list') > -1 ? value.split(',') : [];
  const val = isPhone ? value.replace(/\D/g, '') : value;
  values.forEach((v: any, i: number) => {
    if (isPhone) values[i] = cleanPhoneNumber(v);
  });
  values = values.join("','");
  switch (whereField) {
    case 'contains':
      return `${key} LIKE '%${val}%'`;
    case 'not_contains':
      return `${key} NOT LIKE '%${val}%'`;
    case 'eq':
      return `${key} = ${quote}${val}${quote}`;
    case 'ne':
      return `${key} != ${quote}${val}${quote}`;
    case 'empty':
      return `${key} = '' OR ${key} IS NULL OR ${key} = 'n/a'`;
    case 'in_list':
      return `${key} IN ('${values}')`;
    case 'not_in_list':
      return `${key} NOT IN ('${values}')`;
  }
};

export const getWhereColumn = (prefix: string, column: string) => {
  switch (column) {
    case 'active':
      return `${prefix}.${column}`;
    case 'fullName':
      return 'c.full_name';
    case 'chapter':
      return 'ch.chapter_name';
    case 'username':
      return `${prefix}.${column}`;
    case 'email':
      return 'c.email';
    case 'roles':
      return 'r.role_name';
    case 'address1':
      return 'a.address_1';
    case 'address2':
      return 'a.address_2';
    case 'city':
      return 'a.city';
    case 'state':
      return 'a.state';
    case 'zipCode':
      return 'a.zip_code';
    case 'phone':
      return 'c.phone';
    case 'title':
      return 'c.title';
    case 'memo':
      return `${prefix}.${column}`;
    case 'level':
      return 'rl.level_name';
  }
  return '';
};
