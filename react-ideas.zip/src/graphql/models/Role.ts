import { getConnection, IContextParams } from './index';

export interface IRole {
  id: number;
  userId?: number;
  name: string;
  description: string;
  createDate: string;
  updateDate?: string;
  updatedByUserId?: number;
}

interface IRoleParams {
  ids?: number[];
  userIds?: number[];
}

/**
 * Returns a list of Role objects selected by a list of
 * role_ID's. If no select list is provided, a list of
 * all Role objects in the database is returned.
 *
 * @param {Object<IRoleParams>} args
 * @param {Array<number>} args.ids
 * @param {Array<number>} args.userIds
 * @param {Object<IContextParams>} context
 * @param {Promise<Pool>} context.db
 * @param {Promise<ProcessEnv>} context.env
 *
 * @returns {Promise<IRole[]>}
 */
export const getRoles = async (
  { ids = [], userIds = [] }: IRoleParams,
  { db, env }: IContextParams
) => {
  const db1 = await env.DB1;
  const con = await getConnection(db);
  const hasRole = ids && ids.length;
  const hasUser = userIds && userIds.length;
  const select = hasUser ? ',p.user_ID AS userId' : '';
  const where = hasRole ? `AND ID IN (${ids.join(', ')})` : '';
  const join = hasUser
    ? `INNER JOIN ${db1}.permissions AS p
      ON r.ID = p.role_ID`
    : '';
  const sql = `
    SELECT r.ID as id
           ${select}
           ,r.role_name AS name
           ,r.role_description AS description
           ,r.create_date AS createDate
           ,r.update_date AS updateDate
           ,r.updated_by_user_ID AS updatedByUserId
      FROM ${db1}.roles AS r ${join}
     WHERE r.ID >= 0 ${where}
     ORDER BY r.ID
  `;
  try {
    const results = await con.query(sql, []);
    con.release();

    return results;
  } catch (error) {
    console.error(error);
    con.release();

    return [];
  }
};
