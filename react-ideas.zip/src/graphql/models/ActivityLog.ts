import { getConnection, IContextParams } from './index';
import { IActivity } from './Activity';
import { IUser } from './User';
import { IChapter } from './Chapter';
import { IProgram } from './Program';
import { ILocation } from './Location';
import { IContact } from './Contact';
import { ICounty } from './County';

export interface IActivityLog {
  id: number;
  activityId: number;
  userId: number;
  chapterId: number;
  programId: number;
  locationId: number;
  instructorContactId: number;
  activityDate: string;
  hours: number;
  approved: number;
  memo?: string;
  adminFeedback?: string;
  programTitle?: string;
  activityType: IActivity;
  user: IUser;
  chapter: IChapter;
  program: IProgram;
  location: ILocation;
  instructor: IContact;
  counties: ICounty[];
  createDate: string;
  updateDate?: string;
  updatedByUserId?: number;
}

interface IActivityLogParams {
  ids?: number[];
  userIds?: number[];
  approved?: number | null;
}

/**
 * Returns a list of Activity objects selected by a list of
 * activity_ID's. If no select list is provided, a list of
 * all Activity objects in the database is returned.
 *
 * @param {Object<IActivityLogParams>} args
 * @param {Array<number>} args.ids
 * @param {Array<number>} args.userIds
 * @param {number} args.approved
 * @param {Object<IContextParams>} context
 * @param {Promise<Pool>} context.db
 * @param {Promise<ProcessEnv>} context.env
 *
 * @returns {Promise<IActivityLog[]>}
 */
export const getActivityLogs = async (
  { ids = [], userIds = [], approved = null }: IActivityLogParams,
  { db, env }: IContextParams
) => {
  const db1 = await env.DB1;
  const con = await getConnection(db);
  const hasActivityLog = ids && ids.length;
  const hasUser = userIds && userIds.length;
  let where = hasActivityLog ? `WHERE l.ID IN (${ids.join(', ')})` : 'WHERE l.ID > 0';
  where = hasUser ? `WHERE l.user_ID IN (${userIds.join(', ')})` : where;
  where = approved !== null ? `${where} AND l.approved = ${approved}` : where;

  const sql = `
    SELECT l.ID as id
           ,l.activity_ID AS activityId
           ,l.user_ID AS userId
           ,l.chapter_ID AS chapterId
           ,l.program_ID AS programId
           ,l.location_ID AS locationId
           ,l.instructor_contact_ID AS instructorContactId
           ,l.activity_date AS activityDate
           ,l.hours
           ,l.approved
           ,l.memo
           ,l.admin_feedback AS adminFeedback
           ,l.program_title AS programTitle
           ,l.create_date AS createDate
           ,l.update_date AS updateDate
           ,l.updated_by_user_ID AS updatedByUserId
      FROM ${db1}.activity_logs AS l ${where}
     ORDER BY l.ID
  `;
  try {
    const results = await con.query(sql, []);
    con.release();

    return results;
  } catch (error) {
    console.error(error);
    con.release();
    return [];
  }
};
