import { getConnection, IContextParams } from './index';
import { IContact } from './Contact';
import { IAddress } from './Address';
import { ICounty } from './County';
import { uniq } from 'ramda';

export interface ILocation {
  id: number;
  supervisorContactId?: number;
  name: string;
  supervisor?: IContact;
  addresses: IAddress[];
  counties: ICounty[];
  memo?: string;
  createDate: string;
  updateDate?: string;
  updatedByUserId?: number;
  approved: number;
  active: boolean;
}

interface ILocationParams {
  ids?: number[];
  countyIds?: number[];
  approved?: number | null;
  active?: boolean | null;
}

/**
 * Returns a list of Location objects selected by either a list of
 * location_ID's or county_ID's. If neither select list is provided,
 * a list of all Location objects in the database is returned.
 *
 * @param {Object<ILocationParams>} args
 * @param {Array<number>} args.ids
 * @param {Array<number>} args.countyIds
 * @param {number} args.approved
 * @param {boolean} args.active
 * @param {Object<IContextParams>} context
 * @param {Promise<Pool>} context.db
 * @param {Promise<ProcessEnv>} context.env
 *
 * @returns {Promise<ILocation[]>}
 */
export const getLocations = async (
  { ids = [], countyIds = [], approved = null, active = null }: ILocationParams,
  { db, env }: IContextParams
): Promise<ILocation[]> => {
  let where = 'WHERE l.ID > 0';
  const db1 = await env.DB1;
  const con = await getConnection(db);
  const hasLocation = ids && ids.length;
  const hasCounty = countyIds && countyIds.length;
  const join = hasCounty
    ? `INNER JOIN ${db1}.location_counties AS lc
      ON l.id = lc.location_ID`
    : '';

  where = hasLocation ? `WHERE l.ID IN (${ids.join(', ')})` : where;
  where = hasCounty ? `WHERE lc.county_ID IN (${countyIds.join(', ')})` : where;
  where = approved !== null ? `${where} AND l.approved = ${approved}` : where;
  where = active !== undefined && active !== null ? `${where} AND l.active = ${active}` : where;

  const sql = `
    SELECT l.ID AS id
           ,l.supervisor_contact_ID AS supervisorContactId
           ,l.location_name AS name
           ,l.memo
           ,l.create_date AS createDate
           ,l.update_date AS updateDate
           ,l.updated_by_user_ID AS updatedByUserId
           ,l.approved
           ,l.active
      FROM ${db1}.locations AS l ${join}
     ${where}
     ORDER BY l.ID
  `;
  try {
    const results: ILocation[] = await con.query(sql, []);
    con.release();

    return results ? uniq(results) : results;
  } catch (error) {
    console.error(error);
    con.release();
    return [];
  }
};
