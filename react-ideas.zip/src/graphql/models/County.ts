import { getConnection, IContextParams } from './index';
import { uniq } from 'ramda';

export interface ICounty {
  id: number;
  activityLogId?: number;
  locationId?: number;
  name: string;
  createDate: string;
  updateDate?: string;
  updatedByUserId?: number;
}

interface ICountyParams {
  activityLogIds?: number[];
  locationIds?: number[];
}

/**
 * Returns a list of County objects selected by either a list of
 * activity_log_ID's or location_ID's. If neither select list is provided,
 * a list of all County objects in the database is returned.
 *
 * @param {Object<ICountyParams>} args
 * @param {Array<number>} args.activityLogIds
 * @param {Array<number>} args.locationIds
 * @param {Object<IContextParams>} context
 * @param {Promise<Pool>} context.db
 * @param {Promise<ProcessEnv>} context.env
 *
 * @returns {Promise<ICounty[]>}
 */
export const getCounties = async (
  { activityLogIds = [], locationIds = [] }: ICountyParams,
  { db, env }: IContextParams
) => {
  const db1 = await env.DB1;
  const con = await getConnection(db);
  let select = '';
  let where = '';
  let join = '';
  const hasLocation = locationIds && locationIds.length;
  const hasActivity = activityLogIds && activityLogIds.length;
  join = hasLocation
    ? `INNER JOIN ${db1}.location_counties AS lc
      ON c.id = lc.county_ID`
    : join;

  join = hasActivity
    ? `INNER JOIN ${db1}.activity_counties AS ac
      ON c.id = ac.county_ID`
    : join;

  select = hasLocation ? ',lc.location_ID AS locationId' : select;
  select = hasActivity ? ',ac.activity_log_ID AS activityLogId' : select;
  where = hasLocation ? `WHERE lc.location_ID IN (${locationIds.join(', ')})` : where;
  where = hasActivity ? `WHERE ac.activity_log_ID IN (${activityLogIds.join(', ')})` : where;

  const sql = `
    SELECT c.ID as id
           ${select}
           ,c.county_name AS name
           ,c.create_date AS createDate
           ,c.update_date AS updateDate
           ,c.updated_by_user_ID AS updatedByUserId
      FROM ${db1}.counties c ${join}
     ${where}
     ORDER BY c.ID
  `;
  try {
    const results = await con.query(sql, []);
    con.release();
    return results ? uniq(results) : results;
  } catch (error) {
    console.error(error);
    con.release();
    return [];
  }
};
