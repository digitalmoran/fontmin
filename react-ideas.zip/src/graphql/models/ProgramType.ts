import { getConnection, IContextParams } from './index';

export interface IProgramType {
  id: number;
  type: string;
  createDate: string;
  updateDate?: string;
  updatedByUserId?: number;
}

interface IProgramTypeParams {
  ids?: number[];
}

/**
 * Returns a list of ProgramType objects selected by a list of
 * program_type_ID's. If no select list is provided,
 * a list of all ProgramType objects in the database is returned.
 *
 * @param {Object<IProgramTypeParams>} args
 * @param {Array<number>} args.ids
 * @param {Object<IContextParams>} context
 * @param {Promise<Pool>} context.db
 * @param {Promise<ProcessEnv>} context.env
 *
 * @returns {Promise<IProgramType[]>}
 */
export const getProgramTypes = async (
  { ids = [] }: IProgramTypeParams,
  { db, env }: IContextParams
) => {
  const db1 = await env.DB1;
  const con = await getConnection(db);
  const hasProgramType = ids && ids.length;
  const where = hasProgramType ? `AND ID IN (${ids.join(', ')})` : '';
  const sql = `
    SELECT ID as id
           ,program_type AS type
           ,create_date AS createDate
           ,update_date AS updateDate
           ,updated_by_user_ID AS updatedByUserId
      FROM ${db1}.program_types
     WHERE ID >= 0 ${where}
     ORDER BY ID
  `;
  try {
    const results = await con.query(sql, []);
    con.release();

    return results;
  } catch (error) {
    console.error(error);
    con.release();

    return [];
  }
};
