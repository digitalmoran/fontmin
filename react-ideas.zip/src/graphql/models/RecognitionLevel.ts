import { getConnection, IContextParams } from './index';

export interface IRecognitionLevel {
  id: number;
  name: string;
  description: string;
  level: number;
  createDate: string;
  updateDate?: string;
  updatedByUserId?: number;
}

interface IRecognitionLevelParams {
  ids?: number[];
}

/**
 * Returns a list of RecognitionLevel objects selected by a list of
 * recognition_ID's. If no select list is provided,
 * a list of all RecognitionLevel objects in the database is returned.
 *
 * @param {Object<IRecognitionLevelParams>} args
 * @param {Array<number>} args.ids
 * @param {Object<IContextParams>} context
 * @param {Promise<Pool>} context.db
 * @param {Promise<ProcessEnv>} context.env
 *
 * @returns {Promise<IRecognitionLevel[]>}
 */
export const getRecognitionLevels = async (
  { ids = [] }: IRecognitionLevelParams,
  { db, env }: IContextParams
) => {
  const db1 = await env.DB1;
  const con = await getConnection(db);
  const hasRecognitionLevel = ids && ids.length;
  const where = hasRecognitionLevel ? `WHERE ID IN (${ids.join(', ')})` : '';
  const sql = `
    SELECT ID as id
           ,level_name AS name
           ,level_description AS description
           ,level
           ,create_date AS createDate
           ,update_date AS updateDate
           ,updated_by_user_ID AS updatedByUserId
      FROM ${db1}.recognition_levels ${where}
     ORDER BY ID
  `;
  try {
    const results = await con.query(sql, []);
    con.release();

    return results;
  } catch (error) {
    console.error(error);
    con.release();
    return [];
  }
};
