import * as cluster from 'cluster';
import { cpus } from 'os';
import { runServer } from './server';
import { isLocalBuild, isProd } from './constants';

if (isProd && isLocalBuild) {
  if (cluster.isMaster) {
    cpus().forEach(() => cluster.fork());

    // cluster manager
    cluster.on('exit', (worker, code, signal) => {
      // tslint:disable-next-line:no-console
      console.log(`Restarting ${worker.process.pid}. ${code || signal}`);
      cluster.fork();
    });
  } else {
    runServer();
  }
} else {
  runServer();
}

process.on('uncaughtException', (err) => {
  // tslint:disable-next-line:no-console
  console.error(err);
  process.exit(1);
});

process.on('unhandledRejection', (err) => {
  // tslint:disable-next-line:no-console
  console.error(err);
});
