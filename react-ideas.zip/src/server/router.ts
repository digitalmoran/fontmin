import * as express from 'express';
import { isProd, isLocalBuild } from './constants';

export function router(app: express.Application) {
  if (isProd) {
    app.use(
      isLocalBuild ? '/' : '*',
      express.static(isLocalBuild ? './' : '.', {
        setHeaders: (res, path) => {
          if (path.indexOf('index.html') > -1) {
            res.set(
              'Cache-Control',
              'public, no-store, must-revalidate, immutable, max-age=0, s-maxage=0'
            );
            res.set('Pragma', 'no-store');
            res.set('Expires', '-1');
          } else {
            res.set('Cache-Control', 'public, max-age-3156000, immutable');
          }
        },
      })
    );
    // allow for deep linking
    app.use(
      isLocalBuild ? '/' : '*',
      express.static(isLocalBuild ? './index.html' : process.cwd())
    );
  }
}
