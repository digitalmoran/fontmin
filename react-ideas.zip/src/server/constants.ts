export const GRAPHQL_ENDPOINT = '/graphql';
export const isLocalBuild = process.env.Apple_PubSub_Socket_Render ? true : false;
export const isProd = process.env.NODE_ENV !== 'development';
