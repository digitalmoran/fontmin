import * as mysql from 'promise-mysql';
import { isProd } from './constants';
import { getEnvironment } from '../lib/env';

if (isProd) {
  getEnvironment();
}
const showDebug = process.env.MYSQL_SHOW_DEBUG_INFO === 'true' ? true : false;

export const pool: any = mysql.createPool({
  connectionLimit: 100,
  host: process.env.MYSQL_DB_HOST,
  user: process.env.MYSQL_DB_USER,
  password: process.env.MYSQL_DB_PASS,
  charset: 'utf8mb4',
  debug: showDebug,
});

(async function() {
  if (process.env.NODE_ENV !== 'production') {
    try {
      await pool;
      const _pool = pool.value();
      _pool.on('acquire', function(connection: any) {
        console.log('Connection %d acquired', connection.threadId);
      });
      _pool.on('enqueue', function() {
        console.log('Waiting for available connection slot');
      });
      _pool.on('release', function(connection: any) {
        console.log('Connection %d released', connection.threadId);
      });
    } catch (err) {
      console.error(err);
    }
  }
})();

export default pool;
