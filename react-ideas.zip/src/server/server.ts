import { createServer } from 'http';
import * as express from 'express';
import * as bodyParser from 'body-parser';
import { router } from './router';
import { getEnvironment } from '../lib/env';
import { GRAPHQL_ENDPOINT, isLocalBuild, isProd } from '../server/constants';
import { createServer as gqlServer } from '../graphql/server';
import { resolvers } from '../graphql/resolvers';
import { importSchema } from 'graphql-import';
import { makeExecutableSchema } from 'graphql-tools';
import { ApolloServer } from 'apollo-server-express';
import * as compression from 'compression';
import * as fs from 'fs';

if (isProd) {
  getEnvironment();
}

export async function runServer() {
  let apollo: ApolloServer = await (async function() {
    const schemaPath = isProd ? '/schema' : '/src/graphql/schema';
    const typeDefs = await importSchema(`${process.cwd()}${schemaPath}/schema.gql`);
    const schema = makeExecutableSchema({ typeDefs, resolvers });
    return gqlServer(schema);
  })();

  const app = express();
  let port = process.env.PORT || 3000;
  if (!isProd) {
    port = Number(port) + 1;
  }

  app.use(bodyParser.urlencoded({ extended: true }));
  app.use(bodyParser.json());
  app.use(compression());
  /*const transforms = function(
    req: express.Request,
    res: express.Response,
    next: express.NextFunction
  ) {
    /*if (req.path === GRAPHQL_ENDPOINT) {
      console.log(req);
    }* /
    if (req.path) {
      fs.writeFileSync(`${process.cwd()}/error.log`, `${process.cwd()}\n`, {
        encoding: 'utf8',
        flag: 'a',
      });
    }
    next();
  };

  app.use(transforms);*/
  apollo.applyMiddleware({ app, path: `*${GRAPHQL_ENDPOINT}` });

  // register routes
  router(app);

  const server = createServer(app);
  if (isProd && !isLocalBuild) {
    server.listen();
    fs.writeFileSync(`${process.cwd()}/tmp/pid`, `${process.pid.toString()}`, {
      encoding: 'utf8',
      flag: 'w',
    });
  } else {
    server.listen(port);
  }

  server.on('listening', () => {
    const addr = server.address();
    if (addr) {
      const bind = typeof addr === 'string' ? `pipe ${addr}` : `port ${addr.port}`;
      // tslint:disable-next-line:no-console
      console.log(`Listening on ${bind}`);
    }
  });

  server.on('error', (err: any) => {
    if (err.syscall !== 'listen') throw err;

    const bind = typeof port === 'string' ? `Pipe ${port}` : `Port ${port}`;

    switch (err.code) {
      case 'EACCES':
        // tslint:disable-next-line:no-console
        console.error(`${bind} requires elevated privileges`);
        process.exit(1);
        break;
      case 'EADDRINUSE':
        // tslint:disable-next-line:no-console
        console.error(`${bind} is already in use`);
        process.exit(1);
        break;
      default:
        throw err;
    }
  });
}
