import * as fs from 'fs';
import * as dotenv from 'dotenv';

const envPath = '.env';
// https://github.com/bkeepers/dotenv#what-other-env-files-can-i-use
// https://create-react-app.dev/docs/advanced-configuration
const dotenvFiles = [
  `${envPath}.${process.env.NODE_ENV}.local`,
  `${envPath}.${process.env.NODE_ENV}`,
  // Don't include `.env.local` for `test` environment
  // since normally you expect tests to produce the same
  // results for everyone
  process.env.NODE_ENV !== 'test' && `${envPath}.local`,
  envPath,
].filter(Boolean);

// Parse and load all .env files
export function getEnvironment() {
  return parseEnvironment(true);
}

// Returns an object of the application env settings from all files.
// If loadVariables is set to true, will update process.env as needed
export function parseEnvironment(loadVariables: boolean = false) {
  const config: any = {};
  dotenvFiles.forEach((dotenvFile: any) => {
    if (fs.existsSync(dotenvFile)) {
      const envConfig = dotenv.parse(fs.readFileSync(dotenvFile));
      for (const k in envConfig) {
        if (k) {
          config[k] = envConfig[k];
          if (!process.env[k] && loadVariables) {
            process.env[k] = envConfig[k];
          }
        }
      }
    }
  });
  return config;
}
