export const debounce = (ms: number, fn: any) => {
  let timer: any;
  return function() {
    clearTimeout(timer);
    const args = Array.prototype.slice.call(arguments);
    // @ts-ignore
    args.unshift(this);
    timer = setTimeout(fn.bind.apply(fn, args), ms);
  };
};

export const onNextFrame = (callback: any) => {
  setTimeout(() => {
    requestAnimationFrame(callback);
  });
};

export function generateQuickGuid() {
  return (
    Math.random()
      .toString(36)
      .substring(2, 15) +
    Math.random()
      .toString(36)
      .substring(2, 15)
  );
}
