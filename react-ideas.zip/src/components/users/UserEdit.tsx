import React from 'react';
import Button from '@material-ui/core/Button';
import { makeStyles } from '@material-ui/core/styles';
import CancelIcon from '@material-ui/icons/Cancel';
import { Link } from 'react-router-dom';
import {
  TabbedForm,
  FormTab,
  Edit,
  Toolbar,
  Datagrid,
  TextField,
  DateField,
  TextInput,
  ReferenceManyField,
  NumberInput,
  DateInput,
  BooleanInput,
  EditButton,
  SaveButton,
  required,
} from 'react-admin';
import RichTextInput from 'ra-input-rich-text';

const useStyles = makeStyles((theme) => ({
  button: {
    margin: theme.spacing(1),
    background: '#d70045',
    color: '#fff !important',
    '&:hover': {
      background: '#8f002f',
    },
  },
}));

export interface IProps {
  [key: string]: any;
}

const MyButton = (props: any) => {
  const classes = useStyles();
  return (
    <Button
      className={classes.button}
      startIcon={<CancelIcon />}
      variant="contained"
      color="secondary"
      onClick={() => setTimeout(() => window.scrollTo({ top: 0, left: 0 }), 0)}
      href={`#${props.basePath}`}
    >
      Cancel
    </Button>
  );
};

const UserCreateToolbar = (props: any) => {
  return (
    <Toolbar {...props}>
      <SaveButton color="secondary" label="Save" redirect="show" submitOnEnter={true} />
      <MyButton />
    </Toolbar>
  );
};

export const UserEdit = (props: IProps) => (
  <Edit {...props}>
    <TabbedForm toolbar={<UserCreateToolbar />}>
      <FormTab label="summary">
        <TextInput disabled label="Id" source="id" />
        {/*<TextInput source="title" validate={required()} />
                <TextInput multiline source="teaser" validate={required()} />*/}
      </FormTab>
      <FormTab label="body">
        <RichTextInput source="body" validate={required()} addLabel={false} />
      </FormTab>
      <FormTab label="Miscellaneous">
        {/*<TextInput label="Password (if protected post)" source="password" type="password" />
                <DateInput label="Publication date" source="published_at" />
                <NumberInput source="average_note" validate={[ number(), minValue(0) ]} />
                <BooleanInput label="Allow comments?" source="commentable" defaultValue />
              <TextInput disabled label="Nb views" source="views" />*/}
      </FormTab>
      <FormTab label="comments">
        {/*<ReferenceManyField reference="comments" target="post_id" addLabel={false}>
                    <Datagrid>
                        <TextField source="body" />
                        <DateField source="created_at" />
                        <EditButton />
                    </Datagrid>
            </ReferenceManyField>*/}
      </FormTab>
    </TabbedForm>
  </Edit>
);

export default UserEdit;
