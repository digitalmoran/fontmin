export const getListStyles = (theme: any, HEADER_HEIGHT: number, isIE: boolean) => {
  return {
    grid: {
      width: '100%',
      '& thead th::after': {
        content: '""',
        width: '100%',
        position: 'absolute',
        bottom: '-21px',
        right: 0,
        borderTop: '1px solid #ddd',
        height: '20px',
        background: 'linear-gradient(to bottom, rgba(170,170,170,0.2) 0%,rgba(0,0,0,0) 75%)',
        backgroundPosition: '100% 0',
        pointerEvents: 'none',
        opacity: 0.7,
      },
      '& td': {
        '&.hidden': {
          display: 'none',
        },
        padding: '8px',
        width: '10px',
        maxWidth: '10px',
        minWidth: '10px',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        borderColor: '#f2f2f2',
      },
      '& th': {
        '&.hidden': {
          display: 'none',
        },
        position: isIE ? 'relative' : 'sticky',
        padding: '8px',
        top: `${HEADER_HEIGHT}px`,
        lineHeight: '16px',
        '& > span': {
          height: '30px',
        },
        '&:nth-child(1) > span': {
          margin: '11px 0',
          height: 'auto',
        },
      },
      '& th:nth-child(1)': {
        maxWidth: '20px',
        minWidth: '20px',
        width: '20px',
        textOverflow: 'clip',
      },
      '& td:nth-child(1), & td:nth-child(2)': {
        textOverflow: 'clip',
      },
      '& th:nth-child(2)': {
        minWidth: '60px',
        whiteSpace: 'normal',
      },
      '& th:nth-child(3)': {
        minWidth: '90px',
      },
      '& th:nth-child(4)': {
        minWidth: '80px',
      },
      '& th:nth-child(5)': {
        minWidth: '75px',
      },
      '& th:nth-child(6)': {
        minWidth: '160px',
      },
      '& th:nth-child(7)': {
        minWidth: '95px',
      },
      '& th:nth-child(8)': {
        minWidth: '65px',
      },
      '& th:nth-child(9)': {
        minWidth: '65px',
      },
      '& th:nth-child(10)': {
        minWidth: '95px',
      },
      '& th:nth-child(11)': {
        minWidth: '34px',
      },
      '& th:nth-child(12)': {
        minWidth: '50px',
      },
      '& th:nth-child(13)': {
        minWidth: '42px',
      },
      '& td:nth-child(13)': {
        textOverflow: 'clip',
      },
      '& th:nth-child(14)': {
        minWidth: '90px',
      },
      '& th:nth-child(15)': {
        minWidth: '90px',
      },
      '& th:nth-child(16)': {
        minWidth: '90px',
      },
      '& th:last-child': {
        maxWidth: '45px',
        minWidth: '45px',
        width: '45px',
      },
      '&[data-show-address="false"]': {
        '& th:nth-child(8)': {
          minWidth: '122px',
        },
      },
      '& mark': {
        background: '#d4e8ff',
      },
    },
    listPage: {
      // marginLeft: '240px',
      '& .MuiPaper-root': {
        // width: 'calc(100% - 240px)',
      },
      [theme.breakpoints.only('xs')]: {
        '& .filter-field + .filter-field': {
          transform: 'scale(0.9)',
          transformOrigin: '0 0',
          marginRight: '-126px',
          '& .hide-filter': {
            marginLeft: '-13px',
          },
          width: `${document.body.clientWidth - 16}px`,
        },
        '& > .MuiToolbar-root': {
          maxWidth: `${document.body.clientWidth - 16}px`,
          overflow: 'hidden',
        },
      },
    },
    mobile: {
      [theme.breakpoints.only('xs')]: {
        '& > .MuiCard-root:nth-child(1)::after': {
          content: '""',
          width: '100%',
          height: '20px',
          background: 'linear-gradient(to bottom, rgba(170,170,170,0.2) 0%,rgba(0,0,0,0) 75%)',
          pointerEvents: 'none',
          position: 'absolute',
          top: 0,
          left: 0,
        },
      },
      '& > .MuiCard-root:nth-child(2n)': {
        background: 'rgba(250,250,250, 1)',
      },
    },
    card: {
      borderRadius: 0,
      paddingTop: '10px',
      border: '1px solid #f7f7f7',
      boxShadow: 'none',
      '& .vgroup': {
        display: 'flex',
        flexDirection: 'column',
      },
      '& .hgroup': {
        display: 'flex',
        flexDirection: 'row',
        flexGrow: 0,
      },
      '& .name': {
        display: 'flex',
        padding: '5px 16px 5px 16px',
        fontSize: '13px',
        '& .fullName': {
          marginRight: '5px',
        },
        '& .username': {
          marginTop: '3px',
          fontSize: '11px',
        },
        '& .small': {
          display: 'flex',
          margin: '3px 1px',
          fontSize: '11px',
        },
      },
      '& .chapter': {
        whiteSpace: 'normal',
        fontSize: '13px',
      },
      '& .contact': {
        '& a': {
          marginTop: '2px',
        },
      },
      '& .address': {
        marginTop: '8px',
        fontSize: '13px',
        lineHeight: '16px',
      },
      '& .info': {
        marginTop: '6px !important',
        marginLeft: '0 !important',
        fontSize: '13px',
        '& > div': {
          paddingRight: '10px !important',
        },
        '& strong': {
          display: 'inline-block',
          marginTop: '4px',
          // lineHeight: '17px',
        },
      },
      '& .status': {
        marginTop: '5px',
        marginRight: '25px',
      },
    },
  };
};
