import React, { useEffect, useState } from 'react';
import { Scrollbars } from 'react-custom-scrollbars';
import { debounce, generateQuickGuid } from '../../lib/utils';
import ListField from '../ListField';

let ro: any;

export interface IProps {
  [key: string]: any;
}

export const AdditionalInfo = (props: IProps) => {
  const [scrollWidth, setScrollWidth] = useState<number>(0);
  const divId = generateQuickGuid();

  // componentDidMount
  useEffect(() => {
    ro = new window.ResizeObserver(
      debounce(200, (entries: any, observer: any) => {
        setScrollWidth(entries[0]?.target.offsetWidth || 0);
      })
    );

    const div = document.getElementById(divId);
    ro.observe(div?.parentNode);

    return () => {
      // componentWillUnmount
      if (ro) {
        const div = document.getElementById(divId);
        if (div?.parentNode) {
          ro.unobserve(div.parentNode);
        }
        ro = undefined;
      }
    };
  });

  return (
    <Scrollbars
      data-force-redraw={scrollWidth}
      autoHeight
      className={props.className}
      style={{ margin: '2px' }}
      autoHeightMax={props.maxHeight || 60}
      renderTrackHorizontal={(props: any) => <div {...props} className="track-horizontal" />}
      renderThumbVertical={(props: any) => <div {...props} className="thumb-vertical" />}
    >
      <div id={divId}>
        <div>
          <strong style={{ display: 'inline-block', marginRight: '5px' }}>Roles:</strong>
          <ListField source="permissions" prop="name" {...props} />
        </div>
        {props.record.contact.title && (
          <div>
            <strong style={{ display: 'inline-block', marginRight: '5px' }}>Title:</strong>
            <span>{props.record.contact.title}</span>
          </div>
        )}
        {props.record.memo && (
          <div>
            <strong style={{ display: 'inline-block', marginRight: '5px' }}>Memo:</strong>
            <span>{props.record.memo}</span>
          </div>
        )}
        {props.record.recognitionLevel && (
          <div>
            <strong style={{ display: 'inline-block', marginRight: '5px' }}>Level:</strong>
            <span>{props.record.recognitionLevel.name}</span>
          </div>
        )}
      </div>
    </Scrollbars>
  );
};
AdditionalInfo.defaultProps = { addLabel: true };

export default AdditionalInfo;
