import UserIcon from '@material-ui/icons/PeopleAlt';
import UserList from './UserList';
import UserEdit from './UserEdit';
import UserCreate from './UserCreate';

export default {
  options: { label: 'Users' },
  list: UserList,
  create: UserCreate,
  edit: UserEdit,
  icon: UserIcon,
};
