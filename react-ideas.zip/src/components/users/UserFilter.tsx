import React, { useEffect } from 'react';
import { useSelector } from 'react-redux';
import { Filter, SearchInput } from 'react-admin';
import ComboInput from '../ComboInput';
import * as Mark from 'mark.js';

const UserFilter = (props: any) => {
  // console.log(props);
  // @ts-ignore
  const loading = useSelector((state) => state.admin.loading > 0);
  const deleteMarks = (className: any = null) => {
    const marks = document.querySelectorAll(className || 'mark');
    [].forEach.call(marks, (m: any) => {
      if (m.parentNode) {
        m.parentNode.innerHTML = m.parentNode.innerText.replace(/\n/gm, '');
      }
    });
  };

  // for all-in-one search filter
  useEffect(() => {
    if (props.filterValues.q) {
      const tds = document.querySelectorAll('td');
      if (tds.length && !loading) {
        deleteMarks('.q-mark');
        const highlighter = new Mark(tds);
        const numbersOnly = props.filterValues.q.replace(/\D/g, '');
        const keywords: string[] = [props.filterValues.q];
        keywords.push(numbersOnly);
        highlighter.mark(keywords, {
          className: 'q-mark',
          ignorePunctuation: [' -.\\(\\)'],
          separateWordSearch: false,
          acrossElements: true,
        });
      }
    } else {
      deleteMarks('.q-mark');
    }
  }, [loading, props.filterValues.q, props['data-show-all'], props['data-show-grid']]);

  // begin individual search filters
  // -----------------------------------------------------------------------------------
  const allColumns = [
    ['fullName'],
    ['chapter'],
    ['username'],
    ['email'],
    ['roles'],
    ['address1'],
    ['address2'],
    ['city'],
    ['state'],
    ['zipCode'],
    ['phone'],
    ['title'],
    ['memo'],
    ['level'],
  ];
  // breakpoint 1 columns
  const bp1Columns = [
    ['fullName'],
    ['chapter'],
    ['username'],
    ['email', 'phone'],
    ['address1', 'address2', 'city', 'state', 'zipCode'],
    ['roles', 'title', 'memo', 'level'],
  ];
  const columns = props['data-show-all'] ? allColumns : bp1Columns;

  for (let i = 0; i < columns.length; i += 1) {
    for (let j = 0; j < columns[i].length; j += 1) {
      // eslint-disable-next-line
      useEffect(() => {
        if (
          props.filterValues[columns[i][j]] &&
          props.filterValues[`${columns[i][j]}Where`] === 'contains'
        ) {
          const tds = document.querySelectorAll(`td:nth-child(${i + 3})`);
          if (tds.length && !loading) {
            deleteMarks(`.${columns[i]}-mark`);
            const highlighter = new Mark(tds);
            const keywords: string[] = [props.filterValues[columns[i][j]]];
            if (columns[i][j] === 'phone') {
              const numbersOnly = props.filterValues[columns[i][j]].replace(/\D/g, '');
              keywords.push(numbersOnly);
            }
            highlighter.mark(keywords, {
              className: `${columns[i][j]}-mark`,
              ignorePunctuation: [' -.\\(\\)'],
              separateWordSearch: false,
              acrossElements: true,
            });
          }
        } else {
          deleteMarks(`.${columns[i][j]}-mark`);
        }
      }, [
        loading,
        props.filterValues[columns[i][j]],
        props['data-show-all'],
        props['data-show-grid'],
      ]);
    }
    // end individual search filters
    // -----------------------------------------------------------------------------------
  }
  return (
    <Filter {...props}>
      <SearchInput source="q" alwaysOn autoComplete="off" />
      <ComboInput source="fullName" label="Full Name" {...props} />
      <ComboInput source="chapter" label="Chapter" {...props} />
      <ComboInput source="username" label="Username" {...props} />
      <ComboInput source="email" label="Email" {...props} />
      <ComboInput source="roles" label="Roles" {...props} />
      <ComboInput source="address1" label="Address 1" {...props} />
      <ComboInput source="address2" label="Address 2" {...props} />
      <ComboInput source="city" label="City" {...props} />
      <ComboInput source="state" label="State" {...props} />
      <ComboInput source="zipCode" label="Zip Code" {...props} />
      <ComboInput source="phone" label="Phone" {...props} />
      <ComboInput source="title" label="Title" {...props} />
      <ComboInput source="memo" label="Memo" {...props} />
      <ComboInput source="level" label="Recognition Received" {...props} />
      <ComboInput source="active" label="Active" isBoolean={true} {...props} />
    </Filter>
  );
};

export default UserFilter;
