import React, { useEffect, useState } from 'react';
import { Scrollbars } from 'react-custom-scrollbars';
import { debounce, generateQuickGuid } from '../../lib/utils';

let ro: any;

export interface IProps {
  [key: string]: any;
}

export const AddressColumn = ({ record, className, maxHeight }: any) => {
  const [scrollWidth, setScrollWidth] = useState<number>(0);
  const spanId = generateQuickGuid();

  // componentDidMount
  useEffect(() => {
    ro = new window.ResizeObserver(
      debounce(200, (entries: any, observer: any) => {
        setScrollWidth(entries[0]?.target.offsetWidth || 0);
      })
    );

    const span = document.getElementById(spanId);
    ro.observe(span?.parentNode);

    return () => {
      // componentWillUnmount
      if (ro) {
        const span = document.getElementById(spanId);
        if (span?.parentNode) {
          ro.unobserve(span.parentNode);
        }
        ro = undefined;
      }
    };
  });
  const addr = record.contact.address;
  const cszEmpty =
    (!addr.city || addr.city === 'n/a') &&
    (!addr.state || addr.state === 'n/a') &&
    (!addr.zipCode || addr.zipCode === 'n/a');
  return (
    <Scrollbars
      data-force-redraw={scrollWidth}
      autoHeight
      className={className}
      autoHeightMax={maxHeight || 60}
      style={{ margin: '2px' }}
      renderTrackHorizontal={(props: any) => <div {...props} className="track-horizontal" />}
      renderThumbVertical={(props: any) => <div {...props} className="thumb-vertical" />}
    >
      {(!addr || cszEmpty) && <span id={spanId}>No Address Provided</span>}
      {addr && !cszEmpty && (
        <span id={spanId}>
          {addr.address1 && <div>{addr.address1}</div>}
          {addr.address2 && <div>{addr.address2}</div>}
          <div>
            {`${addr.city}, `}
            {`${addr.state} `}
            {addr.zipCode}
          </div>
        </span>
      )}
    </Scrollbars>
  );
};
AddressColumn.defaultProps = { addLabel: true };

export default AddressColumn;
