import React from 'react';
import { TextField, DateField, ReferenceField, BooleanField, EditButton } from 'react-admin';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardHeader from '@material-ui/core/CardHeader';
import ContactField from './ContactColumn';
import AddressField from './AddressColumn';
import InfoField from './AdditionalInfo';

const MobileList = ({ ids, data, basePath, classes }: any) => {
  return (
    <div className={classes.mobile}>
      {ids.map((id: any) => (
        <Card key={id} className={classes.card}>
          <div className="hgroup" style={{ maxWidth: `${document.body.clientWidth}px` }}>
            <div className="vgroup" style={{ width: '60%' }}>
              <div className="name">
                <TextField className="fullName" record={data[id]} source="contact.fullName" />
                <span className="small">(</span>
                <TextField className="username" record={data[id]} source="username" />
                <span className="small">)</span>
              </div>
              <div
                style={{
                  padding: '0 16px',
                  fontSize: '13px',
                }}
              >
                <div className="contact">
                  <ContactField record={data[id]} />
                </div>
                <div className="address">
                  <AddressField record={data[id]} maxHeight={100} />
                </div>
              </div>
            </div>
            <div style={{ width: '40%' }}>
              <TextField
                className="chapter"
                style={{ display: 'block', margin: '6px 16px 0 0' }}
                record={data[id]}
                source="chapter.name"
              />
              <InfoField className="info" record={data[id]} maxHeight={150} />
            </div>
          </div>
          <CardActions style={{ justifyContent: 'space-between', fontSize: '13px', width: '100%' }}>
            <EditButton resource="users" basePath={basePath} record={data[id]} />
            <BooleanField className="status" record={data[id]} source="active" />
          </CardActions>
        </Card>
      ))}
    </div>
  );
};
MobileList.defaultProps = {
  data: {},
  ids: [],
};

export default MobileList;
