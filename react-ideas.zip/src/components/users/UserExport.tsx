// @ts-nocheck
import { downloadCSV } from 'react-admin';
import jsonExport from 'jsonexport/dist';
import { PHONE_REGEX } from '../../constants';
import { IUser } from '../../graphql/models/User';

const exporter = (users: IUser[]) => {
  const usersForExport: any = users.map((user: IUser) => {
    const match = user.contact.phone.match(PHONE_REGEX);
    const phone =
      match && match[0]
        ? '(' + match[1] + ') ' + match[2] + '-' + match[3] + (match[6] ? ' x ' + match[6] : '')
        : 'n/a';
    const userForExport: any = {
      Id: user.id,
      'Full Name': user.contact.fullName,
      Chapter: user.chapter.name,
      Username: user.username,
      Email: user.contact.email,
      Roles: user.permissions.map((p: any) => p.name).join(', '),
      'Address 1': user.contact.address.address1,
      'Address 2': user.contact.address.address2,
      City: user.contact.address.city,
      State: user.contact.address.state,
      'Zip Code': user.contact.address.zipCode,
      Phone: phone,
      Title: user.contact.title,
      Memo: user.memo,
      Active: user.active ? 'Yes' : 'No',
    };
    if (user.recognitionLevel) {
      userForExport['Recognition Received'] = user.recognitionLevel.name;
    }
    return userForExport;
  });
  jsonExport(usersForExport, {}, (err: any, csv: any) => {
    downloadCSV(csv, 'users'); // download as 'posts.csv` file
  });
};

export default exporter;
