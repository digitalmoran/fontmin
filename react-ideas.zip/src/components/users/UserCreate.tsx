import React from 'react';
import { SimpleForm, Create } from 'react-admin';

export interface IProps {
  [key: string]: any;
}

export const UserCreate = (props: IProps) => (
  <Create {...props}>
    <SimpleForm>
      <></>
    </SimpleForm>
  </Create>
);

export default UserCreate;
