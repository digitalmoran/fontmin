import React from 'react';
import EmailField from '../EmailField';
import PhoneField from '../PhoneField';
import MailIcon from '@material-ui/icons/MailOutline';
import PhoneIcon from '@material-ui/icons/Phone';

export interface IProps {
  [key: string]: any;
}

export const ContactColumn = (props: IProps) => {
  return (
    <>
      <span style={{ whiteSpace: 'nowrap', display: 'flex' }}>
        <MailIcon style={{ display: 'inline-block', marginRight: '5px', width: '16px' }} />
        <EmailField source="contact.email" {...props} />
      </span>
      <span style={{ whiteSpace: 'nowrap', display: 'flex' }}>
        <PhoneIcon style={{ display: 'inline-block', marginRight: '5px', width: '16px' }} />
        <PhoneField source="contact.phone" {...props} />
      </span>
    </>
  );
};
ContactColumn.defaultProps = { addLabel: true };

export default ContactColumn;
