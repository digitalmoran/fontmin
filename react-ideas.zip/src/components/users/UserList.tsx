import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { List, Datagrid, TextField, BooleanField, SimpleList } from 'react-admin';
import { makeStyles } from '@material-ui/core/styles';
import { useMediaQuery } from '@material-ui/core';
import { debounce } from '../../lib/utils';
import { getListStyles } from './styles';
import MobileList from './MobileList';
import UserFilter from './UserFilter';
import EmailField from '../EmailField';
import PhoneField from '../PhoneField';
import ListField from '../ListField';
import ActionsField from '../ActionsField';
import AdditionalInfo from './AdditionalInfo';
import AddressColumn from './AddressColumn';
import ContactColumn from './ContactColumn';
import ScrollField from '../ScrollField';
import exporter from './UserExport';
import Actions from './UserActions';
import { HEADER_HEIGHT, isIE } from '../../constants';

let ro: any;
let initialized = false;
const useStyles = makeStyles((theme) => getListStyles(theme, HEADER_HEIGHT, isIE));

export interface IProps {
  [key: string]: any;
}

export const UserList: React.SFC<IProps> = (props) => {
  const open = useSelector((state: any) => state.admin.ui.sidebarOpen);
  const isXXSmall = useMediaQuery('(max-width:480px)');
  // const isXSmall = useMediaQuery((theme: any) => theme.breakpoints.down('xs'));
  const classes = useStyles();
  let listRef: any;
  let sideBar: any;

  const checkMediaQueries = () => {
    let isOpen = sideBar ? sideBar.className.indexOf(' open') > -1 : open;
    isOpen = sideBar ? sideBar.className.indexOf(' closed') === -1 : isOpen;
    const bp1 = `(min-width: ${isOpen ? 1834 : 1649}px)`;
    let mq = window.matchMedia(bp1);
    return mq.matches;
  };

  const checkComponent = () => {
    let isOpen = !initialized || (sideBar ? sideBar.className.indexOf(' open') > -1 : open);
    isOpen = !initialized || (sideBar ? sideBar.className.indexOf(' closed') === -1 : isOpen);
    const showGrid =
      (isOpen && document.body.offsetWidth > 1182) || (!isOpen && document.body.offsetWidth > 998);
    return showGrid;
  };

  const [state, setState] = useState<any>({
    showAll: checkMediaQueries(),
    showGrid: checkComponent(),
  });

  useEffect(() => {
    initialized = true;
    // eslint-disable-next-line
    listRef = document.querySelector('.user-list');
    // eslint-disable-next-line
    sideBar = document.querySelector('main .MuiDrawer-paper');

    ro = new window.ResizeObserver(
      debounce(20, (entries: any, observer: any) => {
        // handleResize(entries[0].target);
        clearTimeout(ro?.timer);
        document.body.style.overflowX = 'hidden';
        if (ro) {
          ro.timer = setTimeout(() => (document.body.style.overflowX = 'auto'), 1000);
        }
        // console.log('showGrid:', checkComponent());
        setState({ showAll: checkMediaQueries(), showGrid: checkComponent() });
      })
    );
    ro.observe(document.body);

    return () => {
      ro.unobserve(document.body);
      ro = undefined;
    };
  }, []);

  useEffect(() => {
    if (listRef) {
      ro.observe(listRef);
    }
  }, [listRef]);
  useEffect(() => {
    if (sideBar) {
      ro.observe(sideBar);
    }
  }, [sideBar]);

  return (
    <List
      filters={<UserFilter data-show-all={state.showAll} data-show-grid={state.showGrid} />}
      exporter={exporter}
      actions={<Actions />}
      className={`${classes.listPage} user-list`}
      {...props}
      perPage={10}
    >
      {!!state.showGrid ? (
        <Datagrid className={classes.grid} data-show-all={state.showAll}>
          <ActionsField label="Sort (ID)" sortBy="id" />
          <TextField source="contact.fullName" label="Full Name" />
          <TextField source="chapter.name" label="Chapter" />
          <TextField source="username" label="Username" />
          {!state.showAll && <ContactColumn label="Contact Info" sortBy="contact.email" />}
          {state.showAll && <EmailField source="contact.email" label="Email" />}
          {state.showAll && <ListField source="permissions" prop="name" label="Roles" />}
          {state.showAll && (
            <ScrollField source="contact.address.address1" label="Address&nbsp;1" />
          )}
          {state.showAll && (
            <ScrollField source="contact.address.address2" label="Address&nbsp;2" />
          )}
          {state.showAll && <TextField source="contact.address.city" label="City" />}
          {state.showAll && <TextField source="contact.address.state" label="State" />}
          {state.showAll && <TextField source="contact.address.zipCode" label="Zip Code" />}
          {!state.showAll && <AddressColumn label="Address" sortBy="contact.address.address1" />}
          {!state.showAll && <AdditionalInfo label="Additional Info" sortBy="memo" />}
          {state.showAll && <PhoneField source="contact.phone" label="Phone" />}
          {state.showAll && <ScrollField source="contact.title" label="Title" />}
          {state.showAll && <ScrollField source="memo" label="Memo" />}
          {state.showAll && (
            <TextField source="recognitionLevel.name" label="Recognition Received" />
          )}
          <BooleanField source="active" label="Active" />
        </Datagrid>
      ) : (
        <MobileList classes={classes} />
      )}
    </List>
  );
};

export default UserList;
