import React from 'react';
import { Title } from 'react-admin';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import CardHeader from '@material-ui/core/CardHeader';

export default () => {
  return (
    <>
      <Title title="Dashboard" />
      <Card>
        <CardHeader title="Welcome to the administration" />
        <CardContent>
          <div style={{ minHeight: '500px' }}>My dashboard.</div>
        </CardContent>
      </Card>
    </>
  );
};
