import LogIcon from '@material-ui/icons/ListAlt';
/* import UserList from './UserList';
import UserEdit from './UserEdit';
import UserCreate from './UserCreate';*/

export default {
  options: { label: 'Student Activity' },
  // list: UserList,
  // create: UserCreate,
  // edit: UserEdit,
  icon: LogIcon,
};
