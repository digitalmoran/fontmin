import React from 'react';
import { Layout } from '../layout';
import buildDataProvider from '../../graphql/dataProvider';
import { withStyles, createMuiTheme } from '@material-ui/core/styles';
import { Admin, Resource } from 'react-admin';
import { HEADER_HEIGHT, isIE } from '../../constants';
import Dashboard from '../Dashboard';
import users from '../users';
import chapters from '../chapters';
import activity from '../activity';
import programs from '../programs';
import locations from '../locations';
import activityTypes from '../activityTypes';
import programTypes from '../programTypes';
import recognitionLevels from '../recognitionLevels';

const styles: any = {
  app: {
    /*'&::after': {
      content: '""',
      width: '100%',
      height: '100%',
      background: 'url(/tree-tile.jpg) repeat',
      position: 'fixed',
      left: 0,
      top: 0,
    },*/
    '& .mq-xxs main > div': {
      width: `${document.body.clientWidth}px`,
      overflow: 'hidden',
    },
    '& .MuiTableRow-hover:hover .thumb-vertical': {
      width: '10px',
      background: 'rgba(170, 170, 170, 0.5)',
      borderRadius: '3px',
      right: 0,
    },
    '& input::-ms-clear': {
      display: 'none',
    },
    '& .filter-field .MuiInputBase-root': {
      background: 'rgba(255,255,255, 0.5)',
    },
    '& svg[data-testid="false"]': {
      fill: '#d70045',
    },
    '& svg[data-testid="true"]': {
      fill: '#4CAF50',
    },
    '& > div': {
      paddingTop: `${HEADER_HEIGHT}px`,
    },
    '& .MuiDrawer-paper': {
      top: `${50 + HEADER_HEIGHT}px`,
      position: 'sticky',
      // width: '240px',
      // width: '60px',
      marginTop: isIE ? `-${25 + HEADER_HEIGHT}px` : '25px',
      marginBottom: '50px',
    },
    '& .MuiAppBar-root': {
      top: `${HEADER_HEIGHT}px`,
    },
    '& .MuiToolbar-root .MuiButtonBase-root': {
      marginLeft: '3px',
      '& .MuiButton-label': {
        whiteSpace: 'nowrap',
      },
    },
    '& [data-test="bulk-actions-toolbar"]': {
      // opacity: 0.5,
      //backgroundColor: '#f2f2f3',
      background: 'linear-gradient(to bottom, rgb(235,235,236) 0%,#f8f8f8 50%)',
      borderBottom: '1px solid #eee',
    },
    '& .MuiCollapse-wrapper': {
      background: 'rgba(255, 255, 255, 0.3)',
      boxShadow: 'inset 20px 0px 30px rgba(110,110,110,0.1)',
      borderTop: '1px solid #ddd',
    },
    '& [role="menuitem"]': {
      border: '1px solid transparent',
      transition: 'none !important',
      '& svg': {
        transition: 'none',
      },
      '&:hover': {
        border: '1px solid #fff',
        boxShadow: 'inset 2px -3px 10px rgba(72,110,148,0.2)',
        '& svg': {
          fill: '#323244',
        },
        '& *': {
          color: '#323244',
        },
      },
    },
    '& [aria-current="page"]': {
      background:
        'linear-gradient(to bottom, rgba(121, 147, 170, 0.9) 0%,rgba(69, 102, 133, 0.9) 100%)', // 'rgba(72,110,148,0.7)',
      border: '1px solid #fff',
      // boxShadow: 'inset 2px -3px 10px rgba(72,110,148,0.2)',
      '& svg': {
        fill: '#fff !important',
      },
      '& *': {
        color: '#fff !important',
      },
    },
    '& .ql-tooltip': {
      left: '0 !important',
    },
    '& .layout': {
      background: 'transparent',
    },
    '& .MuiTableRow-hover:hover': {
      background: 'rgba(243,246,248, 0.6)',
    },
    '& .tabbed-form .MuiToolbar-root': {
      background: 'rgba(235,235,236, 0.1) !important',
    },
  },
  header: {
    height: `${HEADER_HEIGHT}px`,
    display: 'block',
    width: '100%',
    position: 'fixed',
    overflow: 'hidden',
    top: 0,
    zIndex: 2,
    background: '#19191d',
    // opacity: 0.5,
  },
  footer: {
    height: '406px',
    // width: `${window.innerWidth + fullWidth}px`,
    background: '#111417',
  },
};

const myTheme = createMuiTheme({
  palette: {
    primary: { main: '#323244' },
    secondary: { main: '#456685' },
    error: { main: '#d70045' },
    contrastThreshold: 3,
    tonalOffset: 0.2,
  },
  overrides: {
    MuiAppBar: {
      colorSecondary: {
        background: 'linear-gradient(to bottom, #7993aa 0%,#456685 100%) !important',
      },
    },
    MuiInputBase: {
      root: {
        '&.Mui-disabled': {
          color: '#000 !important',
          opacity: '0.2 !important',
        },
      },
    },
  },
});

export interface IProps {
  [key: string]: any;
}

export class MyApp extends React.PureComponent<IProps> {
  constructor(props: IProps) {
    super(props);
    this.state = { dataProvider: null };
  }
  componentDidMount() {
    buildDataProvider().then((data: any) => {
      this.setState({ dataProvider: data });
    });
  }
  public render() {
    const { dataProvider }: any = this.state;
    const { classes }: any = this.props;
    if (!dataProvider) {
      return (
        <div className="loader-container">
          <div className="loader">Loading...</div>
        </div>
      );
    }

    return (
      <>
        <header className={classes.header} />
        <div className={`${classes.app} app-container`}>
          <Admin dashboard={Dashboard} theme={myTheme} dataProvider={dataProvider} layout={Layout}>
            <Resource name="users" {...users} />
            <Resource name="chapters" {...chapters} />
            <Resource name="student-activity" {...activity} />
            <Resource name="programs" {...programs} />
            <Resource name="locations" {...locations} />
            <Resource name="activity-types" {...activityTypes} />
            <Resource name="program-types" {...programTypes} />
            <Resource name="recognition-levels" {...recognitionLevels} />
          </Admin>
        </div>
        <footer className={classes.footer} />
      </>
    );
  }
}
export const StyledComponent = withStyles(styles)(MyApp);
export default StyledComponent;
