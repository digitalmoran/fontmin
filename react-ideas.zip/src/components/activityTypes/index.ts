import ActivityTypeIcon from '@material-ui/icons/Assignment';
/* import UserList from './UserList';
import UserEdit from './UserEdit';
import UserCreate from './UserCreate';*/

export default {
  options: { label: 'Activity Types' },
  // list: UserList,
  // create: UserCreate,
  // edit: UserEdit,
  icon: ActivityTypeIcon,
};
