import React from 'react';
import { PHONE_REGEX } from '../constants';

export interface IProps {
  [key: string]: any;
}

export const PhoneField: React.SFC<IProps> = ({ source, record }: any) => {
  const path = source.split('.');
  let entity = record;
  path.forEach((p: string) => {
    if (entity[p]) {
      entity = entity[p];
    }
  });
  const match = entity && entity.match(PHONE_REGEX);
  return (
    <>
      {match && match[0] ? (
        <a href={`tel:+1-${match[1]}-${match[2]}-${match[3]}`} style={{ color: '#52799e' }}>
          {'(' + match[1] + ') ' + match[2] + '-'}
          <wbr />
          {match[3] + (match[6] ? ' x ' + match[6] : '')}
        </a>
      ) : (
        <span>n/a</span>
      )}
    </>
  );
};
PhoneField.defaultProps = { addLabel: true };

export default PhoneField;
