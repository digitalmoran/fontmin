import React, { useState, useEffect } from 'react';
import ChipInput from 'material-ui-chip-input';
import Chip from '@material-ui/core/Chip';
import { SelectInput, TextInput, RadioButtonGroupInput } from 'react-admin';
import { makeStyles } from '@material-ui/core/styles';
import { isFF } from '../constants';
import * as qs from 'querystring';

export interface IProps {
  [key: string]: any;
}

export const ComboInput = (props: IProps) => {
  const [where, setWhere] = useState<string>(
    props.filterValues[`${props.source}Where`] || 'contains'
  );
  const [propz, setPropz] = useState<any>({});
  const [chips, setChips] = useState<string[]>([]);
  const { label, source } = props;
  const useStyles = makeStyles((theme) => ({
    select: {
      display: 'inline-block',
      marginBottom: '-15px',
      minWidth: '60px',
      top: isFF ? '16px' : undefined,
    },
    text: {
      marginBottom: '-15px',
    },
    chip: {
      marginBottom: '8px',
      overflow: 'hidden',
      minWidth: '222px',
      '& label[data-shrink="true"]': {
        // background: 'red',
        top: '20px',
        left: '12px',
        zIndex: 2,
      },
      '& label[data-shrink="false"]': {
        color: 'rgba(0, 0, 0, 1) !important',
        top: '11px',
        left: '12px',
      },
      '& input': {
        marginLeft: '12px',
      },
      '& .MuiChip-sizeSmall': {
        marginLeft: '10px !important',
        '& + .MuiChip-sizeSmall': {
          marginLeft: '3px !important',
        },
        '& + .MuiInput-formControl > input': {
          marginLeft: '4px !important',
        },
      },
      '& > div': {
        marginTop: '28px !important',
      },
      '&::after': {
        content: '""',
        width: '100%',
        height: '100%',
        background: '#fbfbfb',
        position: 'absolute',
        top: '18px',
        left: 0,
        zIndex: -1,
      },
    },
    tag: {
      marginTop: '8px',
      marginRight: '0px',
      '&.focused': {
        background: 'highlight',
      },
    },
    radio: {
      height: '50px',
      top: '-4px',
      paddingTop: '2px',
      paddingBottom: '4px',
      display: 'block',
      minWidth: '150px',
      '& > legend': {
        marginBottom: '-6px',
        paddingTop: '6px',
      },
    },
  }));
  const classes = useStyles();

  const handleChange = (e: any) => {
    if (e.target.value === 'empty') {
      setPropz({ value: '' });
      if (!props.filterValues[source]) {
        props.filterValues[source] = 'empty';
        props.filterValues[`${source}Where`] = e.target.value;
        props.setFilters(props.filterValues);
      }
    } else {
      setPropz({});
      if (props.filterValues[source] === 'empty') {
        props.filterValues[source] = undefined;
        props.filterValues[`${source}Where`] = e.target.value;
        props.setFilters(props.filterValues);
      }
    }
    if (e.target.value === 'in_list' || e.target.value === 'not_in_list') {
      if (props.filterValues[source]) {
        setChips(props.filterValues[source].split(','));
      }
    }
    setWhere(e.target.value);
  };
  const handleChipChange = (chips: any) => {
    setChips(chips);
    props.filterValues[source] = chips.join(',');
    props.setFilters(props.filterValues);
  };

  const chipRenderer = (
    {
      value,
      text,
      chip,
      isFocused,
      isDisabled,
      isReadOnly,
      handleClick,
      handleDelete,
      className,
    }: any,
    key: any
  ) => {
    return (
      <Chip
        className={`${className} ${classes.tag} ${isFocused ? 'focused' : ''}`}
        size="small"
        label={text}
        key={key}
        onClick={handleClick}
        onDelete={handleDelete}
        disabled={isDisabled}
      />
    );
  };

  useEffect(() => {
    if (props.filterValues[source] && typeof props.filterValues[source] === 'string') {
      setChips(props.filterValues[source].split(','));
    }
    if (!props.filterValues[`${source}Where`]) {
      const filters = props.filterValues;
      filters[`${source}Where`] = props.isBoolean ? 'eq' : 'contains';
      if (props.isBoolean) {
        filters[source] = true;
      }
      props.setFilters(filters);
    }
    return () => {
      const hash = window.location.hash.split('?');
      const queryVars: any = qs.decode(hash[1]);
      if (queryVars.filter) {
        const filters = JSON.parse(queryVars.filter);

        delete filters[`${source}Where`];
        props.setFilters(filters);
      }
    };
  }, []);

  let choices: any = [
    { id: 'contains', name: 'contains' },
    { id: 'not_contains', name: 'not contains' },
    { id: 'eq', name: 'equals' },
    { id: 'ne', name: 'not equal' },
    { id: 'empty', name: 'empty' },
    { id: 'in_list', name: 'in list' },
    { id: 'not_in_list', name: 'not in list' },
  ];

  if (props.isBoolean) {
    choices = choices.filter((c: any) => c.id === 'eq' || c.id === 'ne');
  }

  return (
    <>
      {props.isBoolean && (
        <RadioButtonGroupInput
          className={classes.radio}
          source={source}
          defaultValue={true}
          choices={[
            { id: true, name: 'Yes' },
            { id: false, name: 'No' },
          ]}
        />
      )}
      {!props.isBoolean && where !== 'in_list' && where !== 'not_in_list' && (
        <TextInput
          className={classes.text}
          label={label}
          source={source}
          autoComplete="off"
          {...propz}
          disabled={where === 'empty'}
          resettable
        />
      )}
      {(where === 'in_list' || where === 'not_in_list') && (
        <>
          <ChipInput
            className={classes.chip}
            label={label}
            defaultValue={chips}
            chipRenderer={chipRenderer}
            newChipKeys={['Enter', ',']}
            onChange={(chips) => handleChipChange(chips)}
            // style={{ width: '222px' }}
          />
        </>
      )}
      <SelectInput
        className={classes.select}
        onChange={handleChange}
        source={`${source}Where`}
        label=""
        defaultValue={props.isBoolean ? 'eq' : 'contains'}
        choices={choices}
      />
    </>
  );
};

export default ComboInput;
