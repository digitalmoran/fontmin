import React from 'react';

export interface IProps {
  [key: string]: any;
}

export const ListField = ({ source, record, prop }: any) => {
  const path = source.split('.');
  let entity = record;
  path.forEach((p: string) => {
    if (entity[p]) {
      entity = entity[p];
    }
  });
  let items: string[] = [];
  entity.map((item: any) => items.push(String(item[prop])));
  // @ts-ignore remove duplicates
  items = [...new Set(items)];
  return (
    <>
      {items.map((item: any, i: number) => (
        <span key={item + i} title={items.join(',')}>
          {i > 0 ? ', ' : ''}
          {item}
        </span>
      ))}
    </>
  );
};
ListField.defaultProps = { addLabel: true };

export default ListField;
