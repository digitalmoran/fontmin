import React, { useEffect, Children, cloneElement } from 'react';
import PropTypes from 'prop-types';
import { useDispatch, useSelector } from 'react-redux';
import { Drawer, makeStyles, useMediaQuery } from '@material-ui/core';
import lodashGet from 'lodash/get';
import { setSidebarVisibility } from 'ra-core';

export const DRAWER_WIDTH = 240;
export const CLOSED_DRAWER_WIDTH = 55;

const useStyles = makeStyles(
  (theme) => ({
    drawerPaper: {
      position: 'relative',
      height: 'auto',
      overflowX: 'hidden',
      width: (props: any) =>
        props.open
          ? lodashGet(theme, 'sidebar.width', DRAWER_WIDTH)
          : lodashGet(theme, 'sidebar.closedWidth', CLOSED_DRAWER_WIDTH),
      transition: theme.transitions.create('width', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
      }),
      backgroundColor: 'transparent',
      marginTop: '0.5em',
      borderRight: 'none',
      [theme.breakpoints.only('xs')]: {
        marginTop: 0,
        height: '100vh',
        position: 'inherit',
        backgroundColor: theme.palette.background.default,
        '& [aria-current="page"]': {
          background:
            'linear-gradient(to bottom, rgba(121, 147, 170, 0.9) 0%,rgba(69, 102, 133, 0.9) 100%)', // 'rgba(72,110,148,0.7)',
          // border: '1px solid #fff',
          // boxShadow: 'inset 2px -3px 10px rgba(72,110,148,0.2)',
          '& svg': {
            fill: '#fff !important',
          },
          '& *': {
            color: '#fff !important',
          },
        },
      },
      [theme.breakpoints.up('md')]: {
        border: 'none',
        marginTop: '1.5em',
      },
      zIndex: 'inherit',
    },
  }),
  { name: 'RaSidebar' }
);

const Sidebar = (props: any) => {
  const { children, closedSize, size, classes: classesOverride, ...rest } = props;
  const dispatch = useDispatch();
  const isXSmall = useMediaQuery((theme: any) => theme.breakpoints.down('xs'));
  const isSmall = useMediaQuery((theme: any) => theme.breakpoints.down('sm'));
  // FIXME negating isXSmall and isSmall should be enough, but unfortunately
  // mui media queries use a two pass system and are always false at first
  // see https://github.com/mui-org/material-ui/issues/14336
  const isDesktop = useMediaQuery((theme: any) => theme.breakpoints.up('md'));
  useEffect(() => {
    if (isDesktop) {
      dispatch(setSidebarVisibility(true)); // FIXME renders with a closed sidebar at first
    } else {
      dispatch(setSidebarVisibility(false));
    }
  }, [isDesktop, dispatch]);
  const open = useSelector((state: any) => state.admin.ui.sidebarOpen);
  useSelector((state: any) => state.locale); // force redraw on locale change
  const handleClose = () => dispatch(setSidebarVisibility(false));
  const toggleSidebar = () => dispatch(setSidebarVisibility(!open));
  const classes = useStyles({ ...props, open });

  return isXSmall ? (
    <Drawer
      variant="temporary"
      open={open}
      PaperProps={{
        className: `${classes.drawerPaper}${open ? ' open' : ' closed'}`,
      }}
      onClose={toggleSidebar}
      {...rest}
    >
      {cloneElement(Children.only(children), {
        onMenuClick: () => setTimeout(handleClose, 500),
      })}
    </Drawer>
  ) : isSmall ? (
    <Drawer
      variant="permanent"
      open={open}
      PaperProps={{
        className: `${classes.drawerPaper}${open ? ' open' : ' closed'}`,
      }}
      onClose={toggleSidebar}
      {...rest}
    >
      {cloneElement(Children.only(children), {
        onMenuClick: () => setTimeout(handleClose, 500),
      })}
    </Drawer>
  ) : (
    <Drawer
      variant="permanent"
      open={open}
      PaperProps={{
        className: `${classes.drawerPaper}${open ? ' open' : ' closed'}`,
      }}
      onClose={toggleSidebar}
      {...rest}
    >
      {children}
    </Drawer>
  );
};

Sidebar.propTypes = {
  children: PropTypes.node.isRequired,
};

export default Sidebar;
