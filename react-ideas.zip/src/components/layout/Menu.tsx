import React, { FC, useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setSidebarVisibility } from 'ra-core';
import SettingsIcon from '@material-ui/icons/Settings';
import MoneyIcon from '@material-ui/icons/AttachMoney';
import AccountIcon from '@material-ui/icons/AccountBox';
import DataIcon from '@material-ui/icons/Dns';
import DashboardIcon from '@material-ui/icons/Dashboard';
import DownloadIcon from '@material-ui/icons/CloudDownload';
import FileCopyIcon from '@material-ui/icons/FileCopy';
import FileCopyIcon1 from '@material-ui/icons/FileCopyOutlined';
import FileIcon from '@material-ui/icons/InsertDriveFileOutlined';
import ActivityEntryIcon from '@material-ui/icons/AssignmentOutlined';
import ApprovedIcon from '@material-ui/icons/AssignmentTurnedIn';
import { useMediaQuery, Theme } from '@material-ui/core';
import MenuItemLink from './MenuItemLink';
import { AppState } from '../../types';
import { isIE } from '../../constants';
import SubMenu from './SubMenu';

import users from '../users';
import chapters from '../chapters';
import activity from '../activity';
import programs from '../programs';
import locations from '../locations';
import activityTypes from '../activityTypes';
import programTypes from '../programTypes';
import recognitionLevels from '../recognitionLevels';

type MenuName = 'accountPages' | 'resourcePages' | 'databasePages';

interface Props {
  dense: boolean;
  logout: () => void;
  onMenuClick: () => void;
}

const Menu: FC<Props> = ({ onMenuClick, dense, logout }) => {
  const [state, setState] = useState({
    accountPages: false,
    resourcePages: false,
    databasePages: false,
  });
  const [selectedMenu, setSelectedMenu] = useState<string>('');

  const isXSmall = useMediaQuery((theme: Theme) => theme.breakpoints.down('xs'));
  const open = useSelector((state: AppState) => state.admin.ui.sidebarOpen);
  const dispatch = useDispatch();

  const handleToggle = (menu: MenuName) => {
    setState((state) => ({ ...state, [menu]: !state[menu] }));
  };

  useEffect(() => {
    setState((state) => ({ ...state, [selectedMenu]: true }));
  }, [selectedMenu]);

  useEffect(() => {
    if (isIE) {
      const sidebar = document.querySelector('.app-container .MuiDrawer-paper');
      if (sidebar) {
        if (!open) {
          window.TinyAnimate.animateCSS(
            sidebar.parentNode,
            'width',
            'px',
            240,
            55,
            500,
            'easeInOutQuart',
            () => {
              //console.log('done!!!111oneone');
            }
          );
          window.TinyAnimate.animateCSS(
            sidebar,
            'width',
            'px',
            240,
            55,
            500,
            'easeInOutQuart',
            () => {
              //console.log('done!!!111oneone');
              const labels: any = sidebar.querySelectorAll(
                '.primary-text, [role="menuitem"] .MuiTypography-root'
              );
              [].forEach.call(labels, (label: any) => {
                label.style.display = 'none';
              });
              const wrapper: any = document.querySelector('.main-menu-wrapper');
              if (wrapper) wrapper.style.width = '55px';
            }
          );
        } else {
          window.TinyAnimate.animateCSS(
            sidebar.parentNode,
            'width',
            'px',
            55,
            240,
            500,
            'easeInOutQuart',
            () => {
              //console.log('done!!!111oneone');
            }
          );
          window.TinyAnimate.animateCSS(
            sidebar,
            'width',
            'px',
            55,
            240,
            500,
            'easeInOutQuart',
            () => {
              const labels: any = sidebar.querySelectorAll(
                '.primary-text, [role="menuitem"] .MuiTypography-root'
              );
              [].forEach.call(labels, (label: any) => {
                label.style.display = 'inline';
              });
              const wrapper: any = document.querySelector('.main-menu-wrapper');
              if (wrapper) wrapper.style.width = '240px';
            }
          );
        }
      }
    }
  }, [isIE, open]);

  const accountItems: any = [
    { to: '/profile', text: 'Profile', icon: SettingsIcon },
    { to: '/orders', text: 'Order History', icon: MoneyIcon },
    { to: '/activity-entry', text: 'Activity Entry', icon: ActivityEntryIcon },
    { to: '/approved-activity', text: 'Approved Activity', icon: ApprovedIcon },
  ];
  const resourceItems: any = [
    { to: '/admin-resources', text: 'Admin Resources', icon: FileIcon },
    { to: '/chapter-resources', text: 'Chapter Resources', icon: FileCopyIcon },
    { to: '/student-resources', text: 'Student Resources', icon: FileCopyIcon1 },
  ];
  const databaseItems: any = [
    { to: '/users', text: users.options.label, icon: users.icon },
    { to: '/chapters', text: chapters.options.label, icon: chapters.icon },
    { to: '/student-activity', text: activity.options.label, icon: activity.icon },
    { to: '/programs', text: programs.options.label, icon: programs.icon },
    { to: '/locations', text: locations.options.label, icon: locations.icon },
    { to: '/activity-types', text: activityTypes.options.label, icon: activityTypes.icon },
    { to: '/program-types', text: programTypes.options.label, icon: programTypes.icon },
    {
      to: '/recognition-levels',
      text: recognitionLevels.options.label,
      icon: recognitionLevels.icon,
    },
  ];

  return (
    <div className="main-menu-wrapper">
      {' '}
      <MenuItemLink
        onClick={() => {
          if (isXSmall) setTimeout(() => dispatch(setSidebarVisibility(false)), 500);
          setTimeout(() => window.scrollTo({ top: 0, left: 0 }));
        }}
        to="/"
        primaryText="My Dashboard"
        leftIcon={<DashboardIcon />}
        exact
        sidebarIsOpen={open}
        dense={dense}
      />
      <SubMenu
        handleToggle={() => handleToggle('accountPages')}
        isOpen={state.accountPages}
        sidebarIsOpen={open}
        name="My Account"
        icon={<AccountIcon />}
        dense={dense}
      >
        {accountItems.map((item: any) => {
          if (window.location.hash.indexOf(item.to) === 1 && selectedMenu === '') {
            setSelectedMenu('accountPages');
          }
          return (
            <MenuItemLink
              onClick={onMenuClick}
              key={item.to}
              to={item.to}
              primaryText={item.text}
              leftIcon={<item.icon />}
              sidebarIsOpen={open}
              dense={dense}
            />
          );
        })}
      </SubMenu>
      <SubMenu
        handleToggle={() => handleToggle('resourcePages')}
        isOpen={state.resourcePages}
        sidebarIsOpen={open}
        name="My Resources"
        icon={<DownloadIcon />}
        dense={dense}
      >
        {resourceItems.map((item: any) => {
          if (window.location.hash.indexOf(item.to) === 1 && selectedMenu === '') {
            setSelectedMenu('resourcePages');
          }
          return (
            <MenuItemLink
              onClick={onMenuClick}
              key={item.to}
              to={item.to}
              primaryText={item.text}
              leftIcon={<item.icon />}
              sidebarIsOpen={open}
              dense={dense}
            />
          );
        })}
      </SubMenu>
      <SubMenu
        handleToggle={() => handleToggle('databasePages')}
        isOpen={state.databasePages}
        sidebarIsOpen={open}
        name="TNP Database"
        icon={<DataIcon />}
        dense={dense}
      >
        {databaseItems.map((item: any) => {
          if (window.location.hash.indexOf(item.to) === 1 && selectedMenu === '') {
            setSelectedMenu('databasePages');
          }
          return (
            <MenuItemLink
              onClick={onMenuClick}
              key={item.to}
              to={item.to}
              primaryText={item.text}
              leftIcon={<item.icon />}
              sidebarIsOpen={open}
              dense={dense}
            />
          );
        })}
      </SubMenu>
      {isXSmall && logout}
    </div>
  );
};

export default Menu;
