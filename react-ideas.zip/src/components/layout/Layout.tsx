import React, { useEffect } from 'react';
import { useMediaQuery } from '@material-ui/core';
import { Layout } from 'ra-ui-materialui/esm/layout';
import { isIE } from '../../constants';
import AppBar from './AppBar';
import Menu from './Menu';
import Sidebar from './Sidebar';

export default (props: any) => {
  const selector = '.app-container .MuiDrawer-paper';
  const isXXSmall = useMediaQuery('(max-width:480px)');
  useEffect(() => {
    if (isIE) {
      const el = document.querySelector(selector);
      window.Stickyfill.add(el);
      return () => {
        window.Stickyfill.remove(el);
      };
    }
  }, []);

  return (
    <Layout
      {...props}
      className={`${isXXSmall ? ' mq-xxs' : ''}`}
      appBar={AppBar}
      sidebar={Sidebar}
      menu={Menu}
      //theme={theme}
    />
  );
};
