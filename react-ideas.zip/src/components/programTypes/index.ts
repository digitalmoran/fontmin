import ProgTypeIcon from '@material-ui/icons/ArtTrack';
/* import UserList from './UserList';
import UserEdit from './UserEdit';
import UserCreate from './UserCreate';*/

export default {
  options: { label: 'Program Types' },
  // list: UserList,
  // create: UserCreate,
  // edit: UserEdit,
  icon: ProgTypeIcon,
};
