import LevelIcon from '@material-ui/icons/Poll';
/* import UserList from './UserList';
import UserEdit from './UserEdit';
import UserCreate from './UserCreate';*/

export default {
  options: { label: 'Recognition Levels' },
  // list: UserList,
  // create: UserCreate,
  // edit: UserEdit,
  icon: LevelIcon,
};
