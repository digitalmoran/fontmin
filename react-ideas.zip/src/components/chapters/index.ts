import ChapterIcon from '@material-ui/icons/Room';
/* import UserList from './UserList';
import UserEdit from './UserEdit';
import UserCreate from './UserCreate';*/

export default {
  options: { label: 'Chapters' },
  // list: UserList,
  // create: UserCreate,
  // edit: UserEdit,
  icon: ChapterIcon,
};
