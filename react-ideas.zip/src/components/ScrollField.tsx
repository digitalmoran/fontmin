import React, { useEffect, useState } from 'react';
import { Scrollbars } from 'react-custom-scrollbars';
import { debounce, generateQuickGuid } from '../lib/utils';

let ro: any;

export interface IProps {
  [key: string]: any;
}

export const ScrollField = ({ record, source, className }: any) => {
  const [scrollWidth, setScrollWidth] = useState<number>(0);
  const spanId = generateQuickGuid();
  const path = source.split('.');
  let entity = record;
  path.forEach((p: string) => {
    if (entity[p]) {
      entity = entity[p];
    }
  });
  entity = typeof entity === 'object' ? '' : entity;

  // componentDidMount
  useEffect(() => {
    ro = new window.ResizeObserver(
      debounce(200, (entries: any, observer: any) => {
        setScrollWidth(entries[0]?.target.offsetWidth || 0);
      })
    );

    const span = document.getElementById(spanId);
    ro.observe(span?.parentNode);

    return () => {
      // componentWillUnmount
      if (ro) {
        const span = document.getElementById(spanId);
        if (span?.parentNode) {
          ro.unobserve(span.parentNode);
        }
        ro = undefined;
      }
    };
  });

  return (
    <Scrollbars
      data-force-redraw={scrollWidth}
      autoHeight
      className={className}
      autoHeightMax={60}
      style={{ maxWidth: '100px', margin: '2px' }}
      renderTrackHorizontal={(props: any) => <div {...props} className="track-horizontal" />}
      renderThumbVertical={(props: any) => <div {...props} className="thumb-vertical" />}
    >
      <span id={spanId}>{entity}</span>
    </Scrollbars>
  );
};
ScrollField.defaultProps = { addLabel: true };

export default ScrollField;
