import React from 'react';
import Button from '@material-ui/core/Button';
import EditIcon from '@material-ui/icons/Edit';
import ViewIcon from '@material-ui/icons/Visibility';
import { makeStyles } from '@material-ui/core/styles';
const btnWidth = 30;
const useStyles = makeStyles((theme) => ({
  field: {
    maxWidth: '50px',
  },
  button: {
    // fontSize: '11px',
    padding: '2px',
    width: `${btnWidth}px !important`,
    minWidth: `${btnWidth}px !important`,
    maxWidth: `${btnWidth}px !important`,
    color: '#52799e',
    '& .MuiButton-label, & .MuiTouchRipple-root': {
      width: `${btnWidth}px !important`,
    },
    '& svg': {
      marginLeft: '10px',
    },
  },
}));

export interface IProps {
  [key: string]: any;
}

export const ActionsField = (props: any) => {
  const classes = useStyles();
  return (
    <span className={classes.field}>
      <Button
        className={classes.button}
        startIcon={<EditIcon />}
        color="primary"
        title="Edit"
        onClick={() => setTimeout(() => window.scrollTo({ top: 0, left: 0 }), 0)}
        href={`#${props.basePath}/${props.record.id}`}
      >
        <></>
      </Button>
      <Button
        className={classes.button}
        startIcon={<ViewIcon />}
        color="primary"
        title="View"
        onClick={() => setTimeout(() => window.scrollTo({ top: 0, left: 0 }), 0)}
        href={`#${props.basePath}/${props.record.id}`}
      >
        <></>
      </Button>
    </span>
  );
};
ActionsField.defaultProps = { addLabel: true };

export default ActionsField;
