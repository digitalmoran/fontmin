import React from 'react';
import { EmailField } from 'react-admin';
import { makeStyles } from '@material-ui/core/styles';
import { EMAIL_REGEX } from '../constants';

export interface IProps {
  [key: string]: any;
}

export const CustomEmailField: React.SFC<IProps> = (props: any) => {
  const path = props.source.split('.');
  let entity = props.record;
  path.forEach((p: string) => {
    if (entity[p]) {
      entity = entity[p];
    }
  });
  entity = typeof entity === 'object' ? 'n/a' : entity;
  const useStyles = makeStyles({
    email: {
      textOverflow: 'ellipsis',
      overflow: 'hidden',
      minWidth: '10px',
      maxWidth: `100%`,
      display: 'block',
      color: entity === 'n/a' ? 'inherit' : '#52799e',
    },
  });
  const classes = useStyles();
  return EMAIL_REGEX.test(entity) ? (
    <EmailField
      className={classes.email}
      {...props}
      title={entity}
      rel="noopener noreferrer"
      target="_blank"
    />
  ) : (
    <span className={classes.email}>{entity}</span>
  );
};

export default CustomEmailField;
