import ProgramIcon from '@material-ui/icons/School';
/* import UserList from './UserList';
import UserEdit from './UserEdit';
import UserCreate from './UserCreate';*/

export default {
  options: { label: 'Programs' },
  // list: UserList,
  // create: UserCreate,
  // edit: UserEdit,
  icon: ProgramIcon,
};
