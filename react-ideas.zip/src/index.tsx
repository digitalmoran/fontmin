import './styles/index.css';
import * as serviceWorker from './serviceWorker';
// @ts-ignore
require('es6-promise/auto');

(async function() {
  //@ts-ignore
  if (!!window.MSInputMethodContext && !!document.documentMode) {
    await import(/* webpackChunkName: "ie11" */ 'whatwg-fetch');
    const p1 = await import(/* webpackChunkName: "ie11" */ 'core-js/features/symbol');
    window.Symbol = p1.default;
    const p2 = await import(/* webpackChunkName: "ie11" */ 'core-js/features/object/assign');
    Object.assign = p2.default;
    const p3 = await import(/* webpackChunkName: "ie11" */ 'core-js/features/array/from');
    Array.from = p3.default;
    const p4 = await import(/* webpackChunkName: "ie11" */ 'core-js/stable');
    let k: any;
    for (k in p4.default) {
      if (k !== 'location' && k !== 'history') {
        window[k] = p4.default[k];
      }
    }
    const p5 = await import(/* webpackChunkName: "ie11" */ 'regenerator-runtime/runtime');
    for (k in p5.default) {
      window[k] = p5.default[k];
    }
    const p6 = await import(/* webpackChunkName: "ie11" */ 'proxy-polyfill');
    for (k in p6.default) {
      window[k] = p6.default[k];
    }
    const p10: any = await import(/* webpackChunkName: "ie11" */ 'stickyfilljs');
    window.Stickyfill = p10.default;
    const p11: any = await import(/* webpackChunkName: "ie11" */ 'TinyAnimate');
    window.TinyAnimate = p11.default;
  }
  if ('ResizeObserver' in window === false) {
    // Loads polyfill asynchronously, only if required.
    const module = await import('@juggle/resize-observer');
    window.ResizeObserver = module.ResizeObserver;
  }
  const p7 = await import('react');
  const React = p7.default;
  const p8 = await import('react-dom');
  const ReactDOM = p8.default;
  const p9 = await import('./components/App');
  const App = p9.default;
  // kill console messages in production
  if (process.env.NODE_ENV === 'production') {
    window.console.log = function() {};
    window.console.warn = function() {};
  }
  ReactDOM.render(<App />, document.getElementById('root'));
})();

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
